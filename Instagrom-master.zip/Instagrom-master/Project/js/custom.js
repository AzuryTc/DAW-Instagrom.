

// --------- FUNCIONES REGISTRO ----------

function validarNombreUsuario ( nombre ){


	var resultado=true;



	var txt =document.getElementById("nombre-usuario").parentNode.parentNode;
	console.log(txt);
	var span=document.createElement("span");
	span.setAttribute("id","snomusu");
	span.innerHTML=" El nombre tiene que tener una longitud mínima de 3 y máxima de 15. \n Solo puede estar compuesto por letras minusculas mayusculas y números y tampoco puede comenzar por numero.";
		
	if(nombre.length<3 || nombre.length>15){

		resultado=false;


	}

	if(nombre.charCodeAt(0)>=48 && nombre.charCodeAt(0)<=57 && resultado==true){ // Probar con numbrer.isNaN()

		resultado = false;

		//alert(" El nombre no puede comenzar por numero");
	}

	for( var i=0; i< nombre.length && resultado== true; i++){

		//Numeros

		if(nombre.charCodeAt(i)<48 || nombre.charCodeAt(i)>122){

			resultado=false;

			//alert("Caracter introducido erroneo");
			break;


		} 
		else if((nombre.charCodeAt(i)>=58 && nombre.charCodeAt(i)<=64) || (nombre.charCodeAt(i)>=91 && nombre.charCodeAt(i)<=96) ) {

			resultado=false;
		//	alert("Caracter introducido erroneo");
			break;

		}

	}

	if( resultado==false){

		if(document.getElementById("snomusu")==null || document.getElementById("snomusu")==undefined  ){
		
			txt.appendChild(span);
		}

		//alert("El nombre no es correcto (introducir que tiene que tener) ");
	}else{

		if(document.getElementById("snomusu")!=null && document.getElementById("snomusu")!=undefined  ){
		
			txt.removeChild(document.getElementById("snomusu"));
		}
	}

return resultado;

}














function validarContrasenya ( contrasenya ){

	var resultado = true;

	var existeMayus = false;

	var existeMin = false;

	var existeNum = false; 

	var txt =document.getElementById("contraseña").parentNode.parentNode;
	console.log(txt);
	var span=document.createElement("span");
	span.setAttribute("id","spancontra");
	span.innerHTML=" La contraseña sólo puede contener letras del alfabeto inglés (en mayúsculas y minúsculas), números, el guion y el guion bajo (subrayado). Al menos debe contener una letra en mayúscula, una letra en minúscula y un número; longitud mínima 6 caracteres y máxima 15.";
		

	//Comprobar longitud



	if(contrasenya.length<6 || contrasenya.length>15){

		resultado=false;

	 
	}

	//Comprobar alfabeto


	for( var i=0; i< contrasenya.length && resultado== true; i++){

		//Comprobar que existen min may y num



		if(contrasenya.charCodeAt(i)>=65 && contrasenya.charCodeAt(i)<=90 && existeMayus==false){

			existeMayus =true;
			

		}else if(contrasenya.charCodeAt(i)>=97 && contrasenya.charCodeAt(i)<=122 && existeMin==false){

			existeMin =true;
			

		} else if(contrasenya.charCodeAt(i)>=48 && contrasenya.charCodeAt(i)<=57 && existeNum==false){

			existeNum =true;
			

		}


		//Comprobaciones de validacion 
		if(contrasenya.charCodeAt(i)==45 || contrasenya.charCodeAt(i)==95  ){

			resultado=false;
			break;

		} else if(contrasenya.charCodeAt(i)<48 && contrasenya.charCodeAt(i)>122){

			resultado=false;
			break;


		} 
		else if((contrasenya.charCodeAt(i)>=58 && contrasenya.charCodeAt(i)<=64 )||( contrasenya.charCodeAt(i)>=91 && contrasenya.charCodeAt(i)<=96) ) {

			resultado=false;	
			break;

		}

	}


	if(existeMin==false || existeMayus==false || existeNum ==false){

		resultado=false ;
	}



	
	if( resultado==false){

		if(document.getElementById("spancontra")==null || document.getElementById("spancontra")==undefined  ){
		
			txt.appendChild(span);
		}

		
	}else{

		if(document.getElementById("spancontra")!=null && document.getElementById("spancontra")!=undefined  ){
		
			txt.removeChild(document.getElementById("spancontra"));
		}
	}
}














function repetirContrasenya (){

	var contraseña1 = document.getElementById("contraseña");
	var contraseña2 = document.getElementById("contraseña-r");

	var txt =document.getElementById("contraseña-r").parentNode.parentNode;
	console.log(txt);
	var span=document.createElement("span");
	span.setAttribute("id","repcontra");
	span.innerHTML=" Las contraseñas no son iguales. ";

	var resultado = false;

	if( contraseña1.value == contraseña2.value ){

		resultado=true;
	}

	if( resultado==false){

		if(document.getElementById("repcontra")==null || document.getElementById("repcontra")==undefined  ){
		
			txt.appendChild(span);
		}

		
	}else{

		if(document.getElementById("repcontra")!=null && document.getElementById("repcontra")!=undefined  ){
		
			txt.removeChild(document.getElementById("repcontra"));
		}
	}


		return resultado;
}













function validarFecha (fecha){

	var hoy= new Date();

	var fechaDiv=fecha.split("-");

	

	var day = fechaDiv[2];
    var month = fechaDiv[1];
    var year = fechaDiv[0];

    var dia=false;
    var mes=false;
    var anyo=false;

    var dmax=0;

    var resultado=true;


    var txt =document.getElementById("fecha-nacimiento").parentNode.parentNode;
	console.log(txt);
	var span=document.createElement("span");
	span.setAttribute("id","fnac");
	span.innerHTML=" La fecha no es correcta ";


	
    if(year<=hoy.getFullYear() && year>-1){



    	anyo=true;
    }

    if((year==hoy.getFullYear() && month>-1 && month<=hoy.getMonth() )||( anyo==true && month>-1 && month<12) ){

    	mes=true;
    }


    switch (parseInt(month)) {  

			     case 1:dmax = 31;break;        
			     case 2: if (year % 4 == 0) dmax = 29; else dmax = 28;break;        
			     case 3:dmax = 31;break;        
			     case 4:dmax = 30;break;        
			     case 5:dmax = 31;break;        
			     case 6:dmax = 30;break;        
			     case 7:dmax = 31;break;        
			     case 8:dmax = 31;break;        
			     case 9:dmax = 30;break;        
			     case 10:dmax = 31;break;       
			     case 11:dmax = 30;break;      
			     case 12:dmax = 31;break;       
	}  


	    if((year==hoy.getFullYear() && month==hoy.getMonth() && day<=hoy.getDate() && day>0 ) ){

	    	dia=true;

	    }else if((year!=hoy.getFullYear() || month!=hoy.getMonth()) && day>0 && (day<=dmax || day<=hoy.getDate()) ){

	    		dia=true;
	    }

	    if(dia==false || mes==false || anyo == false){

	    	resultado=false;
	    }






	    if( resultado==false){

		if(document.getElementById("fnac")==null || document.getElementById("fnac")==undefined  ){
		
			txt.appendChild(span);
		}

		
	}else{

		if(document.getElementById("fnac")!=null && document.getElementById("fnac")!=undefined  ){
		
			txt.removeChild(document.getElementById("fnac"));
		}
	}



	return resultado;

}












function validarGenero (){

	var women = document.getElementById("chica");
	var boy =document.getElementById("chico");

	var resultado= true;

	if (women.checked == false && boy.checked==false){
		resultado ==false;

		alert("Necesitas seleccionar un género .");
	}

	return resultado;


}















function validarEmail (email){

	var resultado=false;

	var localBien= false;

	var dominioBien=false;

	if(email!= null && email!= undefined ){

		if(email.length<255 && email.length > 0){

		if (email.split("@")!=undefined && email.split("@")!=null ){

			

			//Calcular maximos y minimos. 

			var emailSplit = email.split("@");

			var local = emailSplit[0];

			var dominio=emailSplit[1];

			if ( dominio!= undefined && dominio.split(".")!=undefined && emailSplit[1].split(".")!=null ){

				var dominioSplit = emailSplit[1].split(".");

				var dominioConcatenado;

				console.log(emailSplit);

				//comprobar longitudes minimas y maximas

				if(local.length>0 && local.length<65 ){

					localBien=true; 
				}



				if(dominio.length>0 && dominio.length<255){
					dominioBien=true;
				}else{

				dominioBien=false;

					}

					for(var i=0; i<dominioSplit.length;i++){

						if(dominioSplit[i].length<0 || dominioSplit[i].length>63){

							dominioBien=false;
							break;
						}

					}
				


				//validar carácteres local:

				if( localBien==true &&(local.charCodeAt(0)==46 || local.charCodeAt(local.length-1)==46)){

					alert ("El correo electrónico no puede comenzar o finalizar con punto. ")

				} else if(localBien==true){


					for( var i=0; i< local.length; i++){
						
						//comprobar puntos 

						if( local.charCodeAt(i)==46 ){

							var aux=i+1;

							if(aux<local.length && local.charCodeAt(aux)==46 ){


								resultado=false;
								localBien=false;

								alert("Un correo electronico no puede contener dos puntos seguidos");

								break;

							}


						}

					//Comprobar que existen min may y num



						if(local.charCodeAt(i)>=65 && local.charCodeAt(i)<=90 ){

							resultado=true;

						} else if(local.charCodeAt(i)>=94 && local.charCodeAt(i)<=126 ){

							resultado=true;

							

						} else if(local.charCodeAt(i)>=45 && local.charCodeAt(i)<=57){

							resultado = true;

						} else if( local.charCodeAt(i)==33 || ( local.charCodeAt(i)>=35 && local.charCodeAt(i)<=39) ||  local.charCodeAt(i)==42 ||
							 local.charCodeAt(i)==43 || local.charCodeAt(i)==61 || local.charCodeAt(i)==63){
							resultado=true;

						}else{

							resultado = false; 
							localBien=false;
							alert("El correo tiene caracteres incorrectos. El correo puede tener: letras mayúsculas y minúsculas del alfabeto inglés, los dígitos del 0 al 9, los caracteres imprimibles !#$%&'*+-/=?^_`{|}~ y el punto. El punto no puede aparecer ni al principio ni al final y tampoco puede tener dos o más puntos seguidos.")	
							break;
						}

					}
	


					//Validar caracteres dominio.


					if( localBien==true && dominioBien==true && dominioSplit!=undefined ){
				
				
						for(var j=0; j < dominioSplit.length ; j++){
						for(var i=0; i < dominioSplit[j].length ; i++){

							//----------------------------
								if(dominioSplit[j].charCodeAt(0)==45 || dominioSplit[j].charCodeAt((dominioSplit[j].length-1))==45){
										resultado = false; 
									dominioBien=false;

									alert("El dominio contiene un caracter erroneo. Solo puede contener mayusculas, minusculas , numeros y guiones")
									break;

								}

								if(dominioSplit[j].charCodeAt(i)>=65 && dominioSplit[j].charCodeAt(i)<=90 ){

									resultado=true;

								} else if(dominioSplit[j].charCodeAt(i)>=97 && dominioSplit[j].charCodeAt(i)<=122 ){

									resultado=true;
						

								} else if(dominioSplit[j].charCodeAt(i)>=48 && dominioSplit[j].charCodeAt(i)<=57){

									resultado = true;

								} else if( dominioSplit[j].charCodeAt(i)==45){
									resultado=true;

								}else{

									resultado = false; 
									dominioBien=false;

									alert("El dominio contiene un caracter erroneo. Solo puede contener mayusculas, minusculas , numeros y guiones")
									break;
								}



					}	//----------------------------

					}

				}else{

				//	alert ("Error en el dominio del correo");
				}




}
			}

			else{

			alert("Formato de correo incorrecto falta el @");
		
			}
		}

		else{

			alert("falta .XX en el dominio");
		}


 		}else{

 			alert("El e-mail escrito es demasiado largo.")
 		}



	}else{

		alert(" Necesitar definir un correo electrónico");
	}


return resultado;
}
















function revisarFormulario(){


	var op1= validarNombreUsuario ( document.getElementById("nombre-usuario").value);

	var op2= validarContrasenya ( document.getElementById("contraseña").value);

	var op3= repetirContrasenya ();

	var op4= validarFecha (document.getElementById("fecha-nacimiento").value);

	var op5= validarGenero ();

	var op6=validarEmail (document.getElementById("correo").value);


	/*if (op1 && op2 && op3 && op4 && op5 && op6){
		//Enviar datos.
	}else {

		alert("El formulario no esta correctamente, revisalo para poder enviarlo.")
	} */

}








function iniciarSesion() {
		let user = document.getElementById("usuario").value.trim();
		let contra = document.getElementById("contra").value.trim();
		
		if(user === "" || contra === "")
		{
			alert("No puedes iniciar sesión. Comprueba que los campos son correctos");
			return false;
		}
}









function insertarTablaTarifas() {
    var tabla = document.getElementById('precio-tarifas');
    var tr, td;
    for (let i = 1; i <= 15; i += 1) {
        tr = document.createElement('tr');
        tabla.appendChild(tr);
        for (let j = 0; j < 6; j += 1) {
			td = document.createElement('td');
			var x;
			
			if (j === 0) x = i;
			else if(j === 1) x = i*3;
			else {
				if (i > 10) x = 4*0.1 + 6*0.08 + (i-10)*0.07;
				else if (i > 4) x = 4*0.1 + (i-4)*0.08;
				else x = i*0.1;
			}
			
			if(j === 3) x += i*3*0.02;
			else if(j === 4) x += i*3*0.05;
			else if(j === 5) x += i*3*0.05+i*3*0.02;
			
			if (j >= 2) x = x.toFixed(2);

			td.innerText = x;
			tr.appendChild(td);
		}
    }
}