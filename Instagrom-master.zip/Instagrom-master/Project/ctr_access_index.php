<?php
session_start();

/**************************

Archivo: ctr_access_index.php

Creado por: Jenifer Boente y Sergio Sebastián

Controla si un usuario puede acceder a una pagina concreta.

*****************************/

$extra = 'html/index_registrado.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si estas registrado redireccionar a index_registrado
if((isset($_SESSION["user"]) && isset($_SESSION["pass"]))  || (isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) )){
	header("Location: http://$host$uri/$extra");
}
require_once("head-index.php");
?>  
<body>        
	<?php
	require_once("./html/extra/header-sesion-off-index.php");
	?> 
	<?php if(isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) && isset($_COOKIE['count']) && $_COOKIE['count'] > 0): ?>
	<div style="background: #E6E6E6; padding: 5px; border: solid 1px black; border-radius: 10px; text-align: center;">
		<p style="color: black;font-size: 20px;padding: 5px; margin: 5px;" id="warning">La última vez que iniciaste sesión fue: <?php
		echo $_COOKIE['fecha'];
		?> </p>
	</div>
	<?php endif;?>