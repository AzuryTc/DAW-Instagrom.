 <?php
/**************************

Archivo: head_index.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

Historial de cambios:

No hay cambios por ahora.

Funcion: Se corresponde a la cabecera de index sin iniciar sesion.

*****************************/



 ?>


 <!DOCTYPE html>
<html lang="en">

 <head>
        <meta charset="utf-8" />
        <meta name="generator" content="Visual Studio Code" />
        <meta name="author" content="Sergio Sebastián y Jenifer Boente" />
        <meta name="keywords" content="HTML5, web, DAW" />
        <meta name="description" content="Practica de Desarrollo de Aplicaciones Web" />
        
        <link rel="stylesheet" href="css/base.css" type="text/css" media="screen" title="Estilo predeterminado" />
        <link rel="alternate stylesheet" href="css/dark_mode.css" type="text/css" title="Modo oscuro" />
        <link rel="alternate stylesheet" href="css/alto_contraste.css" type="text/css" title="Modo alto contraste" />
        <link rel="alternate stylesheet" href="css/letras_grandes.css" type="text/css" title="Modo letras grandes" />
        <link rel="alternate stylesheet" href="css/accesible.css" type="text/css" title="Estilo accesible" />
        <link rel="stylesheet" href="css/print.css" type="text/css"  media="print" />
        
        <script src="js/custom.js"></script>

        <title>Inicio - Instagrom</title>
    </head>

   