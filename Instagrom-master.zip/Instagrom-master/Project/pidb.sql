-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-12-2020 a las 03:41:51
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pidb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `albumes`
--

CREATE TABLE `albumes` (
  `IdAlbum` int(11) NOT NULL,
  `Titulo` varchar(200) NOT NULL,
  `Descripcion` text NOT NULL,
  `Usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `albumes`
--

INSERT INTO `albumes` (`IdAlbum`, `Titulo`, `Descripcion`, `Usuario`) VALUES
(1, 'Fotos albumsito', '', 1),
(2, 'Comidita', 'Deliciosa comida para mi body', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estilos`
--

CREATE TABLE `estilos` (
  `IdEstilo` int(11) NOT NULL,
  `Nombre` varchar(200) NOT NULL,
  `Descripcion` text NOT NULL,
  `Fichero` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estilos`
--

INSERT INTO `estilos` (`IdEstilo`, `Nombre`, `Descripcion`, `Fichero`) VALUES
(1, 'Normal', 'Este es el estilo normal de la web. Los colores empleados son los colores corporativos de la marca. Se trata de un estilo monocrom?tico, que emplea distintos tonos de naranja.', 'base.css'),
(2, 'Accesible Oscuro', 'Se trata de una version alternativa del estilo. Las caracter?sticas que lo distinguen son: tema oscuro', 'dark_mode.css'),
(3, 'accesible', 'Css accesible', 'acessible.css'),
(4, 'Alto contraste', 'css alternativo de alto contraste', 'alto_contraste.css'),
(5, 'letras grandes', 'Css alternativo con letras de mayor tamaño', 'letras_grandes.css');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fotos`
--

CREATE TABLE `fotos` (
  `IdFoto` int(11) NOT NULL,
  `Titulo` varchar(200) NOT NULL,
  `Descripcion` mediumtext NOT NULL,
  `Fecha` date NOT NULL,
  `Pais` int(11) NOT NULL,
  `Album` int(11) NOT NULL,
  `Fichero` varchar(500) NOT NULL,
  `Alternativo` varchar(200) NOT NULL,
  `FRegistro` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `fotos`
--

INSERT INTO `fotos` (`IdFoto`, `Titulo`, `Descripcion`, `Fecha`, `Pais`, `Album`, `Fichero`, `Alternativo`, `FRegistro`) VALUES
(1, 'Donut', 'Deliciosos donuts', '2020-11-09', 9, 1, 'donut.png', 'foto donut', '2020-11-18 21:38:58'),
(2, 'bombomsitos', 'Ricos bombones de coco ', '2020-12-16', 14, 2, 'bombon.png', '', '2020-12-01 21:48:56'),
(3, 'foto', 'foto de una bola', '2020-12-16', 15, 1, 'foto.jpg', 'foto', '2020-12-01 23:39:18'),
(4, 'Magdalenas', 'Suculentas magdalenas con pepitas de chocolate', '2020-10-14', 1, 2, 'magdalena.png', 'foto de magdalenas', '2020-12-04 21:45:19'),
(26, 'Foto prueba', 'Suculentas magdalenas con pepitas de chocolate', '2020-10-14', 1, 2, 'magdalena.png', 'foto de magdalenas', '2020-12-04 21:45:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE `paises` (
  `IdPais` int(11) NOT NULL,
  `NomPais` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`IdPais`, `NomPais`) VALUES
(0, 'Ninguno'),
(1, 'España'),
(2, 'Colombia'),
(3, 'Alemania'),
(4, 'Francia'),
(5, 'Suiza'),
(6, 'Suecia'),
(7, 'China'),
(8, 'Corea-Norte'),
(9, 'Corea-Sur'),
(10, 'Japón'),
(11, 'EE.UU'),
(12, 'Canadá'),
(13, 'Marruecos'),
(14, 'Sudáfrica'),
(15, 'Australia'),
(16, 'Argentina'),
(17, 'México'),
(18, 'Perú');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `IdSolicitud` int(11) NOT NULL,
  `Album` int(11) NOT NULL,
  `Nombre` varchar(200) NOT NULL,
  `Titulo` varchar(200) NOT NULL,
  `Descripcion` mediumtext NOT NULL,
  `Email` varchar(200) NOT NULL,
  `d_Calle` varchar(200) NOT NULL,
  `d_CP` int(11) NOT NULL,
  `d_Numero` int(11) NOT NULL,
  `d_Pais` int(11) NOT NULL,
  `d_Localidad` int(11) NOT NULL,
  `d_Provincia` varchar(200) NOT NULL,
  `Color` varchar(200) NOT NULL,
  `Copias` int(11) NOT NULL,
  `Resolucion` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `IColor` tinyint(1) NOT NULL,
  `FRegistro` datetime NOT NULL,
  `Coste` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `IdUsuario` int(11) NOT NULL,
  `NomUsuario` varchar(15) NOT NULL,
  `Clave` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Sexo` tinyint(4) NOT NULL,
  `FNacimiento` date NOT NULL,
  `Ciudad` varchar(200) NOT NULL,
  `Pais` int(11) NOT NULL,
  `Foto` varchar(200) NOT NULL,
  `FRegistro` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estilo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`IdUsuario`, `NomUsuario`, `Clave`, `Email`, `Sexo`, `FNacimiento`, `Ciudad`, `Pais`, `Foto`, `FRegistro`, `Estilo`) VALUES
(1, 'Jenifer B P', '1234Asdf', 'La.super.maravillosa.jenifer@boente.com', 2, '2020-01-08', 'lima limon', 6, '/perfil.jpg', '2020-12-15 02:38:09', 1),
(2, 'Sergio', '1234', 'sergio@gmail.com', 2, '2020-10-13', 'cancun', 17, '/perfil.jpg', '2020-12-15 02:38:04', 2),
(3, 'sergio3', '1234', 'sergio3@gmail.com', 2, '2010-02-10', 'Whashington DC', 11, '/perfil.jpg', '2020-12-15 02:38:01', 1),
(4, 'juaan4', '1234', 'juan4@gmail.com', 2, '2008-02-10', 'Sudáfrica', 14, '/perfil.jpg', '2020-12-15 02:37:58', 2),
(5, 'luis5', '1234', 'luis5@gmail.com', 2, '2005-02-10', 'Pekín', 7, '/perfil.jpg', '2020-12-15 02:37:55', 1),
(28, 'Gerardo', '1234', 'holahola12@gmail.es', 2, '2018-12-04', '', 8, '/perfil.jpg', '2020-12-15 02:37:50', 1),
(29, 'Pepa99', '1234', 'guan60@gmail.com', 1, '2018-12-12', '', 0, '/perfil.jpg', '2020-12-15 02:37:36', 1),
(80, 'manolo2', '1234', 'manolo2@pi.es', 2, '1998-11-09', 'San Vicente del Raspeig', 1, '/perfil.jpg', '2020-12-15 02:37:34', 2),
(89, 'JaviQueen', '1234Asdf', 'Javi.thebest@gmail.com', 1, '1998-12-13', 'Minecraft', 9, '52bf0f192978da1441632f0325867f56.png', '2020-12-09 00:54:26', 1),
(90, 'Perladolsa', '1234Asdf', 'perla.thebest@gmail.com', 2, '1998-12-13', 'Minecraft', 13, '52bf0f192978da1441632f0325867f56.png', '2020-12-09 01:02:08', 1),
(91, 'Perladolsa2', '1234Asdf', 'perla.thebest@gmail.com', 2, '1998-12-13', 'Minecraft', 13, '52bf0f192978da1441632f0325867f56.png', '2020-12-09 01:27:34', 1),
(93, 'pepa', '1234Asdf', 'a.h@h.o', 2, '1995-05-19', 'aaaa', 4, '/perfil.jpg', '2020-12-15 02:37:30', 1),
(94, 'Jenifer', '1234', 'La.Hiper.maravillosa.jenifer2.0@boente.com', 2, '1995-05-19', 'Wonderland', 10, '/perfil.jpg', '2020-12-15 02:37:11', 1),
(103, 'Abeto', '1234Asdf', 'aaa@aa.aa', 2, '2020-01-15', 'Minecraft', 13, '../images/fotosPerfil/103.', '2020-12-15 01:00:36', 1),
(104, 'Abeto2', '1234Asdf', 'aaa@aa.aa', 2, '2020-01-15', 'Minecraft', 13, '../images/fotosPerfil/104.', '2020-12-15 01:13:46', 1),
(105, 'Abeto3', '1234Sa', 'aaa@aa.aa', 2, '2020-01-15', 'Minecraft', 13, '../images/fotosPerfil/105.', '2020-12-15 01:19:45', 1),
(114, 'Anacleto', '1234Asdf', 'p@pepe.com', 2, '2020-12-01', 'mordor', 16, '/fotosPerfil/114.png', '2020-12-15 02:20:55', 1),
(115, 'Anacleto2', '1234Asdf', 'p@pepe.com', 2, '2020-12-01', 'mordor', 16, '/fotosPerfil/115.jfif', '2020-12-15 02:21:55', 1),
(116, 'Anacleto3', '1234Asdf', 'p@pepe.com', 2, '2020-12-01', 'mordor', 16, '/fotosPerfil/116.jpg', '2020-12-15 03:32:53', 1),
(117, 'Anacleto4', '1234Asdf', 'p@pepe.com', 2, '2020-12-01', 'mordor', 16, '/fotosPerfil/117.jfif', '2020-12-15 02:24:19', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `albumes`
--
ALTER TABLE `albumes`
  ADD PRIMARY KEY (`IdAlbum`),
  ADD UNIQUE KEY `TituloUnico` (`Titulo`),
  ADD KEY `ajena-Albumes-Usuarios` (`Usuario`);

--
-- Indices de la tabla `estilos`
--
ALTER TABLE `estilos`
  ADD PRIMARY KEY (`IdEstilo`);

--
-- Indices de la tabla `fotos`
--
ALTER TABLE `fotos`
  ADD PRIMARY KEY (`IdFoto`),
  ADD KEY `ajena_Fotos-Album` (`Album`),
  ADD KEY `ajena_Pais-Paises` (`Pais`) USING BTREE;

--
-- Indices de la tabla `paises`
--
ALTER TABLE `paises`
  ADD PRIMARY KEY (`IdPais`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`IdSolicitud`),
  ADD KEY `ajena-Solicitudes-Paises` (`d_Pais`),
  ADD KEY `ajena-Solicitudes-Albumes` (`Album`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`IdUsuario`),
  ADD UNIQUE KEY `NomUsuario` (`NomUsuario`),
  ADD KEY `ajena-Usuario-Estilo` (`Estilo`),
  ADD KEY `ajena-Usuario-Pais` (`Pais`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `albumes`
--
ALTER TABLE `albumes`
  MODIFY `IdAlbum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `estilos`
--
ALTER TABLE `estilos`
  MODIFY `IdEstilo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `fotos`
--
ALTER TABLE `fotos`
  MODIFY `IdFoto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `paises`
--
ALTER TABLE `paises`
  MODIFY `IdPais` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `IdSolicitud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `IdUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `albumes`
--
ALTER TABLE `albumes`
  ADD CONSTRAINT `ajena-Albumes-Usuarios` FOREIGN KEY (`Usuario`) REFERENCES `usuarios` (`IdUsuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `fotos`
--
ALTER TABLE `fotos`
  ADD CONSTRAINT `ajena_Fotos-Album` FOREIGN KEY (`Album`) REFERENCES `albumes` (`IdAlbum`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ajena_Pais-Paises` FOREIGN KEY (`Pais`) REFERENCES `paises` (`IdPais`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD CONSTRAINT `ajena-Solicitudes-Albumes` FOREIGN KEY (`Album`) REFERENCES `albumes` (`IdAlbum`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ajena-Solicitudes-Paises` FOREIGN KEY (`d_Pais`) REFERENCES `paises` (`IdPais`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `ajena-Usuario-Estilo` FOREIGN KEY (`Estilo`) REFERENCES `estilos` (`IdEstilo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ajena-Usuario-Pais` FOREIGN KEY (`Pais`) REFERENCES `paises` (`IdPais`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
