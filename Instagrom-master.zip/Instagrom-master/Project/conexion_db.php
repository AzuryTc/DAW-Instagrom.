<?php


/**************************

Archivo: conexion_db.php

Creado por: Jenifer Boente y Sergio Sebastián

Gestiona la conexion con la base de datos.

*****************************/

// Conecta con el servidor de MySQL 
 $mysqli = @new mysqli( 
	'localhost',   // El servidor  (cambiar al subir la pagina al host del servidor)
	'root',    // El usuario 
	'',          // La contraseña 
	'pidb'); // La base de datos 

	if($mysqli->connect_errno) { 
		echo '<p>Error al conectar con la base de datos: ' . $mysqli->connect_error; 
		echo '</p>'; 
		exit; 
	} 

	if (!$mysqli->set_charset("utf8")) { //(1)
    	printf("Error cargando el conjunto de caracteres utf8: %s\n", $mysqli->error);
    	exit;
	}

?>