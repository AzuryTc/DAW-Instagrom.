<?php
session_start();

/**************************

Archivo: control_acceso.php

Creado por: Jenifer Boente y Sergio Sebastián

Controla el login del usuario, permitiendole logearse si existiese en la base de datos.

*****************************/

	//Redireccion
	$extra = 'html/perfil.php';

	//Necesario para optener la url actual
	$host = $_SERVER['HTTP_HOST'];
	$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');

	$loginOK = "false";

	$user = $_POST["user"];
	$pass = $_POST["pass"];
	

	$estilo = 0;


	require_once("conexion_db.php");
	$sentencia='SELECT * FROM usuarios WHERE NomUsuario="' .$user .'" AND Clave="'.$pass.'"';


	if(!($usuario = $GLOBALS["mysqli"]->query($sentencia))) { 
           echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
           echo '</p>'; 
           exit; 
         } 

         if(mysqli_num_rows($usuario)){

         	$fila = $usuario->fetch_object();

         	$estilo= $fila->Estilo;

            $loginOK = "true";
         }

	//Redirigir con unregister
	if($loginOK == "false"):
		$extra = 'index.php?unregister';
	else:

		$_SESSION["user"] = $_POST["user"];
		$_SESSION["pass"] = $_POST["pass"];
		setcookie('estilo', $estilo, time()+ 90 * 24 * 60 * 60,'/');
	
         
		//comprobamos si el checkbox esta marcado
		if(isset($_POST["remember"])):
			

			
			setcookie('user', $_POST['user'], time()+ 90 * 24 * 60 * 60, '/');
			setcookie('pass', $_POST['pass'], time()+ 90 * 24 * 60 * 60, '/');
			setcookie('count', 0, time()+ 90 * 24 * 60 * 60, '/');
			if(isset($_COOKIE["fecha"])){
				setcookie('last_day',$_COOKIE["fecha"] , time()+ 90 * 24 * 60 * 60, '/');
				setcookie('fecha', date('d M Y, H:i'), time()+ 90 * 24 * 60 * 60, '/');
			}else{
				setcookie('fecha', date('d M Y, H:i'), time()+ 90 * 24 * 60 * 60, '/');
			}
		endif;
	endif;


	header("Location: http://$host$uri/$extra");

	exit;
?>
