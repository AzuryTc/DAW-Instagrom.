<?php
/**************************

Archivo: index.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

Historial de cambios:

29/11/2020: Se añade, mediante acceso a base de datos, la opcion de mostrar las 5 ultimas fotos subidas en la base de datos.

Página principal para el usuario no logeado.

*****************************/





require_once("ctr_access_index.php");
?>
    
        <main>
            <div>
                <h1>Últimas fotos</h1>
                <form action="html/busqueda.php" method="GET" id="form-buscar">
                    <label>Búsqueda: &nbsp;<input type="text" id="busqueda" name="busqueda"></label>
                    <input type="submit" value="Buscar" class="button">

                </form>
            </div>
            
            <ul id="fotos">


        <?php 

        require_once("conexion_db.php");

        $sentencia = 'SELECT * FROM fotos';
        if(!($resultado = $mysqli->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
            echo '</p>'; 
            exit; 
        }


        if(mysqli_num_rows($resultado) >= 1){
            mostrarUltimasImagenes();
        }

        $resultado->free();




            function mostrarUltimasImagenes(){



        //extraigo las fotos indicando por cual pagina debo empezar y cuantas imagenes mostrar como tope
        $sentencia = 'SELECT f.IdFoto ,f.Titulo,f.Fichero,f.Alternativo,f.Fecha,p.NomPais, f.FRegistro, u.NomUsuario, u.IdUsuario FROM fotos f JOIN albumes a ON a.IdAlbum=f.Album  JOIN usuarios u ON a.Usuario=u.IdUsuario JOIN paises p ON (p.IdPais = f.Pais)' . ' ORDER BY (f.FRegistro) DESC ' . 'LIMIT 5 ' ;

        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            while($fila = $resultado->fetch_assoc()){

                $id = $fila["IdFoto"];
                $tit = $fila["Titulo"];
                $archivo = $fila["Fichero"];
                $alt = $fila["Alternativo"];
                $dia = date('d/m/Y', strtotime($fila["Fecha"]));
                $pais = $fila["NomPais"];                                                       
                $user = $fila["NomUsuario"];
                $idUsu=$fila["IdUsuario"];
                
                

                echo<<<articulo
                <li>
                    <div class="div-img" >
                    <a href="html/error.php"> <img class="img" src="./images/$archivo" alt="$alt" title="$tit"></a>
                    </div>
                    <h2><a href="html/error.php">$tit</a></h2>
                    <ul>
                        <li>$dia</li>
                        <li>$pais</li>
                        
                    </ul>
                    <p>Imagen de :</p>
                    <p><a href="html/perfil_publico.php?perfil=$idUsu" class="button">$user</a> </p>
                </li>
articulo;
            }
        }

}
         ?>



                
            </ul>
            <?php
                $filas = file("seleccionadas.txt");
                $num = count($filas);
                $seleccionada = mt_rand(1, $num-1);
                $partes = explode('"',$filas[$seleccionada]);
                
                $idFoto = $partes[0];
                $seleccionador = $partes[1];
                $comentario = $partes[2];
                $sentencia = "SELECT fo.Fichero fi, fo.Alternativo al, fo.Titulo ti, fo.Descripcion de, fo.FRegistro fr, fo.Fecha fe, pa.NomPais np, al.IdAlbum id, al.Titulo ta, us.NomUsuario na FROM fotos fo INNER JOIN albumes al ON al.IdAlbum = fo.Album INNER JOIN paises pa ON fo.Pais = pa.IdPais INNER JOIN usuarios us ON al.Usuario = us.IdUsuario WHERE fo.IdFoto = {$idFoto}";
                



                if(!($resultado = $mysqli->query($sentencia))) { 
                    echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error;    echo '</p>';   exit; 
                    }
                $fila = $resultado->fetch_assoc();
            
                echo "
                    <section style='margin-top:10px; border:2px solid black; padding:5px;'>
                        <h2>Foto seleccionada</h2>
                        <article>
                            <p>Seleccionada por: <output>{$seleccionador}</output></p>
                            <p>Comentario: <output>{$comentario}</output></p>
                            <figure>
                                <a href='foto.php?id={$idFoto}'><img src='images/{$fila['fi']}' alt='{$fila['al']}'></a>    
                                <figcaption>
                                    <h2><output>{$fila['ti']}</output></h2>
                                    <p>Descripcion: <output>{$fila["de"]}</output></p>
                                    <p>Fecha de subida: <output><time datetime='{$fila['fr']}'>".date('d/m/Y H : i', strtotime($fila['fr']))."</time></output></p>
                                    <p>Fecha: <output><time datetime='{$fila['fe']}'>".date('d/m/Y', strtotime($fila['fe']))."</time></output></p>
                                    <p>País: <output>{$fila["np"]}</output></p>
                                    <p>Álbum: {$fila["ta"]}</p>
                                    <p>Autor: {$fila['na']}</p>
                                </figcaption>
                            </figure>
                        </article>
                    </section>"; 

                    $str = file_get_contents('html/consejos.json');
                    $json = json_decode($str, true);
                    $num = count($json['consejos']);
                    $seleccionada = mt_rand(0, $num-1);

                    $consejo = $json['consejos'][$seleccionada];

                    echo "
                        <section style='margin-top:10px; border:2px solid black; padding:5px;'>
                            <h2>Consejo del día</h2>
                            <ul>
                                <li>Categoría: {$consejo['categoria']}</li>
                                <li>Dificultad: {$consejo['dificultad']}</li>
                                <li>Descripción: {$consejo['descripcion']}</li>
                            <ul>
                        </section>"; 
            ?>
    
    
        </main>

        <footer>
            <p> &copy; Instagrom 2020</p>
            <a href="accesibilidad.php">Accesibilidad</a>
            <p> Jenifer Boente y Sergio Sebastián</p>
        </footer>
    </body>
</html> 
    