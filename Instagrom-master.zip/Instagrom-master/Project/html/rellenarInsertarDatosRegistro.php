<?php
/**************************

Archivo: rellenarInsertarDatosRegistro.php

Creado por: Jenifer Boente y Sergio Sebastián

Este archivo sirve para concatenar los datos para el inser de registro.

*****************************/
	
	$insertarDatos = "''";
	
	foreach ($sanearPost as $key => $value) {
		if($key == 'contraseña-repetir' || $key == 'imagen'){
			$insertarDatos = $insertarDatos;
		}
		else{
			if(!empty($value)){
				if(is_numeric($value)){
					$insertarDatos = $insertarDatos . ',' . $value;
				}
				
				else{
					$insertarDatos = $insertarDatos . ',' . "'". $value . "'";
				}
			}
			else{
				$insertarDatos = $insertarDatos . ",''";
			}
			
		}
	}

?>