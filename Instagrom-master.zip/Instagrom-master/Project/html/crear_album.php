<?php
session_start();


    /**************************

    Archivo: crear_album.php

    Creado por: Jenifer Boente y Sergio Sebastián

    Página que permite al usuario crear un álbum.

    *****************************/

$extra = 'perfil_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si NO estas registrado redireccionar a inaccesible
if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
    header("Location: http://$host$uri/$extra");
}
    $Titulo="Crear Album - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>
    
    <main>
        <h1>Crea un álbum</h1>
        <form method="POST" action="guardar_album.php">
            <p>
                <label for="nameAlbum">Título: </label>
                <input type="text" id="nameAlbum" name="nameAlbum" autofocus required placeholder="Nombre del álbum"> 
            </p>
            <p>
                <label for="descripcion">Descripción: </label>
                <textarea rows="4" cols="50" id="descripcion" name="descripcion" placeholder="Descripción"></textarea>
            </p>
            <input type="submit" value="Crear" class="button">
        </form>
    </main>
    
    <?php
    require_once("./extra/footer.php");
    ?>    
