<?php
session_start();


/**************************

Archivo: respuesta_registro.php

Creado por: Jenifer Boente y Sergio Sebastián

Comprueba los datos de registro para aceptarlo o denegarlo.

*****************************/

$Titulo="Registro - Instagrom";
     require_once("./extra/head.php");
?>


 <?php
     require_once("./extra/header-sesion-start.php");
    ?>
    

	<main>

		<section class="controlregistro" style="text-align:center; font-size: 20px;">




			<?php 

			$hayPost=false;

			foreach ($_POST as $value){
		        if(isset($value) && !empty($value)){

		            $hayPost=true;


		        }
	    	}



		    if($hayPost==true){

		    	if($_POST["contraseña"]==$_POST["contraseña-repetir"]){
		    		require_once("./extra/resultado-registro-bien.php");
		    	}else{

			    echo"<p> ERROR: Las contraseñas no coinciden. Por favor, vuelve hacia atrás para registrarte de nuevo. </p>";
			    echo '<a href="registro.php" class="button">REGÍSTRATE</a>';

				}

		    	 

		    }else{
			    echo"<p> ERROR: El formulario no es correcto. Por favor, vuelve hacia atrás para registrarte de nuevo. </p>";
			    echo '<a href="registro.php" class="button">REGÍSTRATE</a>';

			} ?>
			
		</section>




	</main>

 <?php
 require_once("./extra/footer.php");
 ?>   
