<?php
session_start();

/**************************

Archivo: foto.php

Creado por: Jenifer Boente y Sergio Sebastián

Página que muestra la foto seleccionada.

*****************************/

$extra = 'perfil_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si NO estas registrado redireccionar a inaccesible
if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
    header("Location: http://$host$uri/$extra");
}
    $Titulo="Foto - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>

<main>
<?php
require_once("../conexion_db.php");
	if((isset($_SESSION["user"]) && isset($_SESSION["pass"]))  || (isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) )){
		$idfoto = $_GET['id'];

		$sentencia= 'SELECT f.Titulo, a.Titulo AS AlbumTit, IdAlbum, Fichero, f.Descripcion, f.Fecha, Alternativo, NomPais, NomUsuario, a.Usuario AS Usuario FROM fotos f JOIN albumes a ON (f.Album = a.IdAlbum) JOIN usuarios ON (a.Usuario = usuarios.IdUsuario) JOIN paises ON (f.Pais = paises.IdPais) WHERE IdFoto = ' .$idfoto;
		

		if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
           $fila = $resultado->fetch_object();

                echo<<<articulo
                <h1>$fila->Titulo</h1>
				<img src="../images/$fila->Fichero" alt="$fila->Alternativo" class="imgResultado">
				<p>$fila->Descripcion</p>
				<ul>

				    <li>Fecha:$fila->Fecha</li>
				    <li>País: $fila->NomPais</li>
				    <li>Álbum: $fila->AlbumTit</li>
				    <li>Usuarios: $fila->NomUsuario</li>
				</ul>
articulo;
            }
       } 
		
	?>
</main>

<?php
 require_once("./extra/footer.php");
 ?>

   