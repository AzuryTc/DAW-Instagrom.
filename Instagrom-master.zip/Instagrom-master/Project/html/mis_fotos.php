<?php
session_start();

/**************************

Archivo: mis_fotos.php

Creado por: Jenifer Boente y Sergio Sebastián

Página que muestra las fotos del usuario.

*****************************/

$extra = 'perfil_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si NO estas registrado redireccionar a inaccesible
if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
    header("Location: http://$host$uri/$extra");
}
    $Titulo="Mis albumes - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>

    <main>

        <h1>Mis Fotos:</h1>

    <ul id="fotos">
 
    <?php
     require_once("../conexion_db.php");


        $usuario=$_SESSION["user"];
    
        $sentencia = 'SELECT f.Descripcion,a.IdAlbum,a.Titulo as NomAlbum,f.IdFoto,f.Titulo as NomFoto, f.Fichero, f.Alternativo, f.Fecha  FROM fotos f JOIN albumes a ON (f.Album=a.IdAlbum)  JOIN usuarios u ON (a.Usuario=u.IdUsuario) WHERE u.NomUsuario="'.$usuario.'"' ;
        
        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            while($fila = $resultado->fetch_assoc()){

                
                $desc=$fila["Descripcion"];
                $idalbum=$fila["IdAlbum"];
                $nomAl=$fila["NomAlbum"];
                $id = $fila["IdFoto"];
                $tit = $fila["NomFoto"];
                $archivo = $fila["Fichero"];
                $alt = $fila["Alternativo"];
                $dia = $fila["Fecha"];
             

          
                

                echo<<<articulo
                <li>
                <img class="img" src="../images/$archivo" alt="$alt" title="$tit" >
                    <h3>$tit</h3>
                    <p>$desc</p>
                    <a href="ver_album_privado.php?album=$idalbum" class="button">$nomAl</a>

                </li>
articulo;
            } 
        }






    ?>
    </ul>
    <br>
    <br>


    </main>

<?php
require_once("./extra/footer.php");
?>   
