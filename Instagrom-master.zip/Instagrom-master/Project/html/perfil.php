    <?php
    session_start();

    /**************************

    Archivo: perfil.php

    Creado por: Jenifer Boente y Sergio Sebastián

    Página de perfil del usuario.

    *****************************/

    $extra = 'perfil_inaccesible.php';
    $host = $_SERVER['HTTP_HOST'];
    $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    //si NO estas registrado redireccionar a inaccesible
    if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
        header("Location: http://$host$uri/$extra");
    }
    $Titulo="Perfil - Instagrom";
    require_once("./extra/head.php");
    ?>


    <?php
    require_once("./extra/header_control.php");
    ?>

    <main>
        <h1>Mi perfil</h1>

        <?php


        require_once("../conexion_db.php");

        $usuarioNom=$_SESSION["user"];


        $sentencia = 'SELECT * FROM  usuarios JOIN paises ON (usuarios.Pais = paises.IdPais) WHERE NomUsuario="'.$usuarioNom.'"';


        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            $fila = $resultado->fetch_object();

            $Nombre=$fila->NomUsuario;
            $fotousu=$fila->Foto;
            $fechaRegistro=$fila->FRegistro;
            $ciu=$fila->Ciudad;
            $pais=$fila->NomPais;
            $email=$fila->Email;
            $cumpleanyos=$fila->FNacimiento;

            $genero=$fila->Sexo;

            if($genero==1){

                $sex="chica";

            }else{

                $sex="chico";

            }



            echo<<<articulo



            <img src="../images$fotousu" alt="foto de perfil del usuario" class="userPerfilImg">

            <br>
            <br>
            <p>Nombre:  $Nombre </p>
            <p>Es usuario desde:  $fechaRegistro </p>
            <p>Email: $email; </p>
            <p>Sexo: $sex</p>
            <p>Fecha de nacimiento: $cumpleanyos</p>
            <p>Pais: $pais </p>
            <p>Ciudad: $ciu </p>

articulo;

        }

        ?>




    <p>

     <form action="datos_usuario.php" method="post">
         <input type="submit" name="submit" value="Descargar Datos XML" />
     </form>

    
    </p>
    <ul id="fotos">
        <li><a href="modificar_datos.php">Editar perfil</a></li>
        <li><a href="mis_albumes.php">Ver tus álbumes</a></li>
        <li><a href="mis_fotos.php">Ver tus fotos</a></li>
        <li><a href="solicitar_album.php">Solicitar álbum impreso</a></li>
        <li><a href="crear_album.php">Crear álbum</a></li>
        <li><a href="crear_foto.php">Crear foto</a></li>
        <li><a href="darme_de_baja.php">Darse de baja</a></li>
        <li><a href="logout.php">Salir</a></li>

    </ul>
    </main>

    <?php
    require_once("./extra/footer.php");
    ?>   
