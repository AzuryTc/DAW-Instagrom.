<?php
session_start();


    /**************************

    Archivo: busqueda.php

    Creado por: Jenifer Boente y Sergio sebastian 

    Página que contiene un formulario de búsqueda de fotos.

	*****************************/
	
    $Titulo="Busqueda - Instagrom";
         require_once("./extra/head.php");
    ?>
   
	<?php
     require_once("./extra/header_control.php");
    ?>


		<main>
			
			<form  method="get" action="resultados.php"> 
				<fieldset>
					<legend>FORMULARIO DE BÚSQUEDA</legend>
					<p>
						<label> Título de la imagen:
						<input type="text" name="Titulo:" size="25"></label>
					</p>
					
					<p>
						<label> Fecha entre :
						<input type="date" name="Desde:" size="25"> y <input type="date" name="Hasta:" size="25"></label>
					</p>
					
					<p>
						<label>
							
							<p><label> País  : <select name="pais">
							

							<?php
								require_once("../conexion_db.php");

								require_once("./extra/listadoPaises.php");
							?>

						</select>
						</label>
					</p>

					<p>
						<input type="submit" value="Buscar" class="button">
						<input type="reset" value="Borrar" class="button">
					</p>
				</fieldset>
			</form>
		</main>

		 <?php
         	require_once("./extra/footer.php");
         ?>
