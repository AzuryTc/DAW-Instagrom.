﻿<?php
    session_start();

    /**************************

    Archivo: accesibilidad.php

    Creado por: Sergio sebastian 

    Página que avisa al usuario de la existencia de estilos alternativos.

    *****************************/
    $Titulo="Accesibilidad - Instagrom";
    require_once("./extra/head.php");
    ?>        
    <?php
    require_once("./extra/header_control.php");
    ?>

    <main>
       <h1>Estilos y Accesibilidad</h1>
       <p>Esta página cuenta con varios estilos, algunos de ellos accesibles. Seleccione el que prefiera:</p>

       <?php
       
       require_once("../conexion_db.php");

       $sentencia3 = 'SELECT  * FROM estilos' ;


       if(!($resultado = $GLOBALS["mysqli"]->query($sentencia3))) { 
        echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
        echo '</p>'; 
        exit; 
    }

    if(mysqli_num_rows($resultado) >= 1){


        while($fila = $resultado->fetch_assoc()){

            $estilo = $fila["Nombre"];

            echo " <a class='button' href='respuesta_configurar.php?estilo=$estilo' style='margin: 3px;'>$estilo</a> ";



        }

    }



    ?>

   
    
    </main>

    <?php
    require_once("./extra/footer.php");
    ?>

