<?php 
/**************************

Archivo: header-sesion-off-index.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

header para usuario no logueado en index.php
*****************************/
?>
<header>
    

    <div id="logo">
        <a href="index.php"><img src="images/logo.png" alt="Logotipo de Instagrom"></a>
        <h1>Instagrom</h1>
    </div>

    <form method="post" onsubmit="return iniciarSesion()" action="control_acceso.php" id="iniciar_sesion">

        <div>
            <h3>Iniciar sesión</h3>
            <a href="html/registro.php" class="button">REGÍSTRATE</a>
        </div>

        <span><label> Nombre de usuario:<input type="text" name="user" id="usuario" size="25"></label> </span>

        <span><label> Contraseña : <input type="password" name="pass" id="contra" size="25"></label> </span>

        <label><input type="checkbox" name="remember" id="remember"> Recordarme en este sitio </label>

        <span><input type="submit" value="Iniciar sesion" class="button"></span>

        <?php if(isset($_GET["unregister"])): ?>
        <p style="color: red;font-size: 15px;padding: 5px;" id="warning">Usuario o Contraseña incorrectos</p>
        <?php endif ?>

    </form>
        
</header>
<body>

        