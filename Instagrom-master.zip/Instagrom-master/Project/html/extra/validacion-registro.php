<?php
	
/**************************

Archivo: validacion-registro.php

Creado por: Jenifer Boente y Sergio sebastian 

Archivo para validar los datos introducidos en un registro o una modificacion.
*****************************/

	$NumError=-1;
	$expReg = [];
	$expReg[] = "/^[A-Za-z0-9]{3,15}$/";
	$expReg[] = "/^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])[A-Za-z0-9_]{6,15}$/";
	$expReg[] = "/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.([a-zA-Z]{2,4})$/";
	
	// Filtra un número entero en un intervalo 
 	$int_options = array("options" => array("min_range" => 1, "max_range" => 3)); 

	$datosCorrectos = false;

	foreach ($sanearPost as $key => $value) {
		if($key == "nombre"){
			if(!empty($value)){
				if(preg_match_all($expReg[0], $value)){
					$datosCorrectos = true;
				}
				else{
					$NumError=0;
					$datosCorrectos = false;
					break;
				}
			}
			else{
				$NumError=1;
				$datosCorrectos = false;
				break;
			}
		}
		if($key == "contraseña"){
			if(!empty($value)){
				if(preg_match_all($expReg[1], $value)){
					$datosCorrectos = true;
				}
				else{
					$NumError=2;
					$datosCorrectos = false;
					break;
				}
			}
			else{
				$NumError=3;
				$datosCorrectos = false;
				break;
			}
		}
		if($key == "correo"){
			if(!empty($value)){
				if(preg_match_all($expReg[2], $value)){
					$datosCorrectos = true;
				}
				else{
					$NumError=4;
					$datosCorrectos = false;
					break;
				}
			}
			else{
				$NumError=5;
				$datosCorrectos = false;
				break;
			}
		}
		if($key == "genero"){
			if(!empty($value) && filter_var($value, FILTER_VALIDATE_INT, $int_options)){
				$datosCorrectos = true;
			}
			else{
				$NumError=6;
				$datosCorrectos = false;
				break;
			}
		}
		if($key == "fecha"){
			if(!empty($value)){
				$fec = strtotime($value);
				$fecha = date('Y-m-d', $fec);
				if($fecha == $value){
					$fechaActual = date('Y-m-d');
					if($value < $fechaActual){
						$datosCorrectos = true;
					}
					else{
						$NumError=7;
						$datosCorrectos = false;
						break;
					}
				}
				else{
					$NumError=8;
					$datosCorrectos = false;
					break;
				}
			}
			else{
				$NumError=9;
				$datosCorrectos = false;
				break;
			}
		}
	}

?>