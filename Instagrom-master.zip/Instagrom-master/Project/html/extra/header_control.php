<?php 
/**************************

Archivo: header_control.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

control de acceso a la pagina
*****************************/
?><?php
    if(isset($_SESSION["user"]) && isset($_SESSION["pass"])):
        require_once("header-sesion-start.php");
    elseif(isset($_COOKIE["user"]) && isset($_COOKIE["pass"])):
        require_once("header-sesion-start.php");
    else:
        require("header-sesion-off.php");	
    endif;
?>