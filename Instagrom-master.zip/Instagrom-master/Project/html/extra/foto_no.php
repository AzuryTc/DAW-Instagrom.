<?php 
/**************************

Archivo: foto_no.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

pagina de error que avisa de que necitas loguearte para acceder.
*****************************/
?>
<h2>Detalle de foto</h2>
<div>
    <p style="font-size: 20px; margin-top: 5px;">No puedes acceder al detalle de una foto si no estas logueado. <a href="../index.php">Pulsa aquí para iniciar sesion.</a></p>
</div>