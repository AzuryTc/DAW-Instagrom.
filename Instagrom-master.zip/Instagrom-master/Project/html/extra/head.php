<?php 
/**************************

Archivo: head.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

Archivo con la cabecera de la web

*****************************/
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="generator" content="Visual Studio Code" />
  <meta name="author" content="Sergio Sebastián y Jenifer Boente"/>
  <meta name="keywords" content="HTML5, web, DAW" />
  <meta name="description" content="Práctica de Desarrollo de Aplicaciones Web" />

  <?php	
  if(isset($_COOKIE['estilo'])):
    switch ($_COOKIE['estilo']) {
      case '2':?>
        <link rel="stylesheet" href="../css/dark_mode.css" type="text/css"  />
        <?php   break;

      case '3':?>
        <link rel="stylesheet" href="../css/accesible.css" type="text/css"  />
        <?php   break;

      case '4':?>
        <link rel="stylesheet" href="../css/alto_contraste.css" type="text/css"  />
        <?php   break;

      case '5':?>
        <link rel="stylesheet" href="../css/letras_grandes.css" type="text/css"  />
        <?php   break;
      
      default:?>
      <link rel="stylesheet" href="../css/base.css" type="text/css" />
      <?php   break;
    }
  else: ?>
    <link rel="stylesheet" href="../css/base.css" type="text/css"  />
  <?php  endif; ?>

  <link rel="stylesheet" href="../css/print.css" type="text/css"  media="print" />

  <script src="../js/custom.js"></script>

  <title>  <?php echo $Titulo ?></title>

</head>
