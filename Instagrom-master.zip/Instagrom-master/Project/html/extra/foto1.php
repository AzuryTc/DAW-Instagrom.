﻿<h1>Bola Especial 1</h1>
<img src="../images/foto.jpg" alt="Imagen del logo" class="imgResultado">
<ul>
    <li>Fecha: 11/8/2020</li>
    <li>País: España</li>
    <li>Álbum: Las alcachofas</li>
    <li>Usuarios: Pedro</li>
</ul>