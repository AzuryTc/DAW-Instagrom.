<?php 
/**************************

Archivo: modificar.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

Archivo con el formulario para registro y para modificar los datos

*****************************/
?>


<p><label> Nombre de usuario : <input id="nombre-usuario"  type="text" name="nombre"></label></p>
<p><label> Contraseña: <input id="contraseña" type="password" name="contraseña"></label>
	<p><label> Repetir contraseña: <input id="contraseña-r" type="password" name="contraseña-repetir"></label></p>
	<p><label> Correo electrónico: <input id="correo" type="text" name="correo"></label></p>
	<p>Género:
		
		<input type="radio" name="genero" id="chico" value="1">  <label for="chico">Hombre</label>
		<input type="radio" name="genero" id="chica" value="2">  <label for="chica">Mujer</label>
	</p>

	<p><label> Fecha de nacimiento: <input id="fecha-nacimiento" type="date" name="fecha"></label></p>
	<p><label> Ciudad: <input id="ciudad" type="text" name="cuidad" ></label></p>
	<p><label> País de residencia : <select name="pais">
		<?php

		require_once("./extra/listadoPaises.php");
		?>

	</select>
</p>

<p><label> Foto de perfil:   <input type="file" id="f-perfil" name="imagen"  /></label></p>

<p>
	<input type="submit" value="Enviar" class="button">
	<input type="reset" value="Borrar" class="button">
</p>