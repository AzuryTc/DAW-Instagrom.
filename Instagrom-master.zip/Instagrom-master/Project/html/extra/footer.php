<?php 
/**************************

Archivo: footer.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

archivo con el pie de pagina .
*****************************/
?>	

	<footer>
	    <p> &copy; Instagrom 2020</p>
	    <a href="accesibilidad.php">Accesibilidad</a>
	    <p> Jenifer Boente y Sergio Sebastián</p>
	</footer>
   </body>
</html> 