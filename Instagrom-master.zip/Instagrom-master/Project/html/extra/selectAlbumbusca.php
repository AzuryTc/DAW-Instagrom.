<?php
session_start();


/**************************

Archivo: selectAlbumbusca.php

Creado por: Jenifer Boente y Sergio sebastian 

Archivo para buscar los albumes que tiene un usuario.
*****************************/
                       
if(isset($_SESSION["user"]) && isset($_SESSION["pass"])){

 
$sentencia='SELECT * FROM usuarios WHERE NomUsuario="' .$_SESSION["user"] .'" AND Clave="'.$_SESSION["pass"].'"';



    if(!($usuario = $GLOBALS["mysqli"]->query($sentencia))) { 
           echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
           echo '</p>'; 
           exit; 
         } 
         if(mysqli_num_rows($usuario)){

            

            $fila = $usuario->fetch_object();
            $id=$fila->IdUsuario;
            ObtenerAlbum($id);

            

         }
   
}else{
    echo "Error no hay usuario";
}




function ObtenerAlbum($id){


 $sentencia2 = 'SELECT * FROM albumes JOIN usuarios  ON (albumes.Usuario = usuarios.IdUsuario) ;





     if(!($resultado = $GLOBALS["mysqli"]->query($sentencia2))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                echo '</p>'; 
                exit; 
     }

        if(mysqli_num_rows($resultado) >= 1){
            while($fila = $resultado->fetch_assoc()){


                $id = $fila["IdAlbum"];
                $tit = $fila["Titulo"];
             


                echo " <option id='$id'>$tit</option>";
            

            }
        }
}


?>