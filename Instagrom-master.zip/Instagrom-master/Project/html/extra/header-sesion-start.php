<?php 
/**************************

Archivo: header-sesion-start.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

header para usuario logueado que muestra su foto de perfil y que le da acceso al mismo
*****************************/
?><header>
	<div id="logo">
		 <a href="index_registrado.php"><img src="../images/logo.png" alt="Logotipo de Instagrom"></a>
		<h1>Instagrom</h1>
	</div>

	<form method="get" action="perfil.php" >

		 <?php


        require_once("../conexion_db.php");

        $usuarioNom=$_SESSION["user"];


        $sentencia = 'SELECT * FROM  usuarios JOIN paises ON (usuarios.Pais = paises.IdPais) WHERE NomUsuario="'.$usuarioNom.'"';


        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            $fila = $resultado->fetch_object();

            $Nombre=$fila->NomUsuario;
            $fotousu=$fila->Foto;
          

            
            echo<<<articulo
            
             <span>
			<a href="perfil.php"><img src="../images$fotousu" alt="foto de perfil del usuario" class="userImg"> Hi, $Nombre  </a>
	    </span>

         

articulo;
            
        }
        ?>



	   

	    <span><input type="submit" value="perfil" class="button"></span>

	</form>

</header>