<?php
session_start(); 
/**************************

Archivo: ctr_acces_no_restrictivo.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

Control de paginas gestionar a que pagina redireccionar  al usuario a una pagina de error en caso de que intente acceder a la parte privada

*****************************/
$extra = 'registro_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si estas registrado redireccionar a inaccesible
if((isset($_SESSION["user"]) && isset($_SESSION["pass"]))  || (isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) )){
	header("Location: http://$host$uri/$extra");
}
     require_once("./extra/head.php");
?>


 <?php
     require_once("./extra/header-sesion-off.php");
     require_once("../conexion_db.php");
 ?>