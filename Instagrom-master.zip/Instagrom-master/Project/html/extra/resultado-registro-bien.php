<?php 
/**************************

Archivo: resultado-registro-bien.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

Archivo con resultado de registro

*****************************/
$Titulo="Registro - Instagrom";
require_once("./ctr_acces_no_restrictivo2.php");

?>

 <h3 style="color:orange">¡El registro ha sido todo un éxito!</h3>

<?php
require_once("../../conexion_db.php");

$sanearGet = $_GET;
	foreach($sanearGet as $key => $value){
		$GLOBALS["mysqli"]->real_escape_string($value);
	}

	$sentencia = "SELECT * FROM usuarios WHERE NomUsuario =".$sanearGet["usu"];

	        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            $fila = $resultado->fetch_object();

            $Nusuario=$fila->NomUsuario;
            $mail=$fila->Email;
            $gen=$fila->Sexo;
            $fnac=$fila->FNacimiento;
            $pai=$fila->Pais;
            $cui=$fila->Ciudad;
            $fotousu=$fila->Foto;

            



            echo<<<articulo

           

			<hr>
			<fieldset>
			<legend> Datos de usuario .</legend>
			<img src="../../images$fotousu" alt="foto de perfil del usuario" class="userPerfilImg">
			<p><b>Nombre de usuario:</b> <output>$Nusuario</output></p>
			<p><b>Email:</b> <output>$mail</output></p>
			<p><b>Ciudad:</b> <output>$cui</output></p>
			<p><b>País:</b> <output>$pai</output></p>
			<p><b>Sexo:</b> <output>$gen</output></p>
			<p><b>Fecha de nacimiento:</b> <output>$fnac</output></p>
			</fieldset>
			
            
articulo;
            
        }


?>	
	</main>

 <?php
 require_once("./footer.php");
 ?>   



