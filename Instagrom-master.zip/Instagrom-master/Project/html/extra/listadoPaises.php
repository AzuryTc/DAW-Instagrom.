<?php 
/**************************

Archivo: listadoPaises.php

Creado por:Jenifer Boente Pereira y Sergio sebastian 

Archivo con el select que te devuelve todos los paises de la base de datos
*****************************/
?>

<option selected value="">Selecciona</option>
<?php



		$sentencia1 = 'SELECT * FROM paises p ORDER BY (NomPais) ASC';
				


		if(!($resultado1 = $GLOBALS["mysqli"]->query($sentencia1))){
			echo "<p>Error al ejecutar la sentencia <b>$sentencia1</b>: " . $GLOBALS["mysqli"]->error; 
			echo '</p>'; 
			exit; 
		}
		while($fila1 = $resultado1->fetch_assoc()){
			$IdPais = $fila1["IdPais"];
			$nomPais = $fila1["NomPais"];

			echo '<option  value="'.$IdPais.'">'.$nomPais.'</option>';
			
		}
		$resultado1->free();


?>

