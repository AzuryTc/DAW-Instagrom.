<?php
session_start();


    /**************************

    Archivo: guardar_foto.php

    Creado por: Jenifer Boente y Sergio Sebastián

    Sube la foto a la base de datos.

    *****************************/

    $extra = 'perfil_inaccesible.php';
    $host = $_SERVER['HTTP_HOST'];
    $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    //si NO estas registrado redireccionar a inaccesible
    if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
        header("Location: http://$host$uri/$extra");
    }
    $Titulo="Crear Album - Instagrom";
    require_once("./extra/head.php");
    require_once("./extra/header_control.php");
        
    require_once("../conexion_db.php");

    $titulo = "";
    $descripcion = "";
    $fecha = "";
    $pais = "";
    $album = "";
    $fichero = "";
    $alternativo = "";

    if(isset($_POST["titulo"])) $titulo = $_POST["titulo"];
    if(isset($_POST["descripcion"])) $descripcion = $_POST["descripcion"];
    if(isset($_POST["fecha"])) $fecha = $_POST["fecha"];
    if(isset($_POST["pais"])) $pais = $_POST["pais"];
    if(isset($_POST["album"])) $album = $_POST["album"];


    if( !empty($_FILES["foto-nueva"]) && is_uploaded_file($_FILES["foto-nueva"]["tmp_name"]) ){

        if($_FILES["foto-nueva"]["error"] > 0) {
            echo " Error".$_FILES["foto-nueva"]["error"].": Se ha producido un error en el archivo de subida.";
            exit;


        }  else { 

                    $usuarioNom=$_SESSION["user"];

                    $contraseña=$_SESSION["pass"];


                 $sentencia = 'SELECT * FROM  usuarios JOIN paises ON (usuarios.Pais = paises.IdPais) WHERE NomUsuario="'.$usuarioNom.'" AND Clave='. $contraseña;


                if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
                    echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                    echo '</p>'; 
                    exit; 
                }

                if(mysqli_num_rows($resultado) >= 1){
                    $fila = $resultado->fetch_object();

                    $idusu=$fila->IdUsuario;
                  

                }

                $arrayNomArchivo = explode(".", $_FILES['foto-nueva']['name']);

                $extensionArchivo = $arrayNomArchivo[sizeof($arrayNomArchivo) - 1];

                $date = getdate();

                $fechaSaneada =$date["hours"]. "-" .$date["minutes"]. "-" .$date["seconds"]."_".$date["mday"]. "-" .$date["mon"]. "-" .$date["year"]; 

                $fichero = $idusu. "_". $fechaSaneada  . "." . $extensionArchivo;

                $directorio="../images/" . $fichero; 

                
                move_uploaded_file($_FILES["foto-nueva"]["tmp_name"], $directorio );
                
                
                 
                
               
            
        }


    

    if(isset($_POST["alternativo"])){
        $alternativo2 = $_POST["alternativo"];
        $subAlternativo = substr($alternativo2, 0, 4);
        $subAlternativo2 = substr($alternativo2, 0, 6);

        if(strlen($alternativo2) > 9 && strcmp($subAlternativo, "foto") && strcmp($subAlternativo2, "imagen"))
        {
            $alternativo = $alternativo2;

            $sentencia = 'INSERT INTO fotos (Titulo, Descripcion, Fecha, Pais, Album, Fichero, Alternativo) VALUES ("'.$titulo.'", "'.$descripcion.'", "'.$fecha.'", '.$pais.', '.$album.', "'.$fichero.'", "'.$alternativo.'")' ;

            if(!($foto = $GLOBALS["mysqli"]->query($sentencia))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                echo '</p>'; 
                exit; 
            }
            else{

                $extra = 'index_registrado.php';
                $host = $_SERVER['HTTP_HOST'];
                $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
                header("Location: http://$host$uri/$extra");
            }
        }
        else
        {
            echo "ERROR: Texto alternativo incorrecto";
        }
    }
    else
    {
        echo "ERROR: No hay ningún texto alternativo";
    }

    } else {

        echo "ERROR : La imagen no se ha subido correctamente";
    }
    
    require_once("./extra/footer.php");

    ?>
