

    <!------------------------

	Archivo: control_registro.php

	Creado por: Jenifer Boente

	Página que muestra los datos del registro en caso de que todo vaya bien,
	en caso contrario, te redirige a una pagina de error.

	------------------------->

<section class="controlregistro" style="text-align:center; font-size: 20px;">
	<?php if($_POST["password"]==$_POST["passwordconfirm"]): ?>
		<h3 style="color:orange">¡El registro ha sido todo un éxito!</h3>
		<hr>
		<p><b>Nombre de usuario:</b> <output><?php echo $_POST["usuario"];?></output></p>
		<p><b>Contraseña:</b> <output><?php echo $_POST["password"];?></output></p>
		<p><b>Email:</b> <output><?php echo $_POST["email"];?></output></p>
		<p><b>Ciudad:</b> <output><?php echo $_POST["registro-ciudad"];?></output></p>
		<p><b>País:</b> <output><?php echo $_POST["registro-pais"];?></output></p>
		<p><b>Sexo:</b> <output><?php echo $_POST["sexo"];?></output></p>
		<p><b>Fecha de nacimiento:</b> <output><?php echo $_POST["edad"];?></output></p>

		<!-- <?php
			foreach($_POST as $clave => $valor){
				echo "$clave: $valor<br /><br/>";
			}
		 ?> -->
	<?php else:
		// Variables para controlar la ruta
		$host = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra = 'registro.php?FAIL';
		header("Location: http://$host$uri/$extra");
		exit;
	endif;?> 
</section>

