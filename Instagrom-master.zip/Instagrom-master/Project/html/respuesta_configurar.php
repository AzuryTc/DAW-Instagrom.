﻿<?php
    session_start();

    /**************************

    Archivo: respuesta_configurar.php

    Creado por: Sergio sebastian 

    Activa el cambio de estilo.

    *****************************/
    require_once("../conexion_db.php");
 
    if (isset($_GET['estilo'])) {
        $sentencia4 = 'SELECT  * FROM estilos WHERE Nombre="'.$_GET["estilo"] .'"';

        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia4))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia4</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){

            while($fila = $resultado->fetch_assoc()){

                $estiloFichero = $fila["Fichero"];
                $idEstilo = $fila["IdEstilo"];

                $sentencia5 = 'UPDATE usuarios SET Estilo="'.$idEstilo .'" WHERE NomUsuario="'.$_SESSION["user"] .'"';

                if(!($estilo = $GLOBALS["mysqli"]->query($sentencia5))) { 
                    echo "<p>Error al ejecutar la sentencia <b>$sentencia5</b>: " . $mysqli->error; 
                    echo '</p>'; 
                    exit; 
                } 

                $sentencia6 = 'SELECT * FROM usuarios WHERE NomUsuario="' .$_SESSION["user"] .'"';


                if(!($usuario = $GLOBALS["mysqli"]->query($sentencia6))) { 
                    echo "<p>Error al ejecutar la sentencia <b>$sentencia6</b>: " . $mysqli->error; 
                    echo '</p>'; 
                    exit; 
                } 

                if(mysqli_num_rows($usuario)){
                    $fila = $usuario->fetch_object();
                    $estilo1= $fila->Estilo;
                    setcookie('estilo', $estilo1, time()+ 90 * 24 * 60 * 60,'/');

                    $extra = 'respuesta_configurar.php';
                    $host = $_SERVER['HTTP_HOST'];
                    $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
                    header("Location: http://$host$uri/$extra");
                }
            }
        }
    }

    $Titulo="Nuevo Estilo - Instagrom";
    require_once("./extra/head.php");
?> 

<?php
require_once("./extra/header_control.php");
?>

<main>
    <h1>Estilos y Accesibilidad</h1>
    <p>Nuevo estilo activado</p>
</main>

<?php
require_once("./extra/footer.php");
?>