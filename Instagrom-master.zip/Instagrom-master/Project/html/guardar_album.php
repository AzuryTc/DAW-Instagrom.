<?php
session_start();


    /**************************

    Archivo: guardar_album.php

    Creado por: Jenifer Boente y Sergio Sebastián

    Sube el album a la base de datos.

    *****************************/

    $extra = 'perfil_inaccesible.php';
    $host = $_SERVER['HTTP_HOST'];
    $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    //si NO estas registrado redireccionar a inaccesible
    if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
        header("Location: http://$host$uri/$extra");
    }
    $Titulo="Crear Album - Instagrom";
    require_once("./extra/head.php");

    require_once("./extra/header_control.php");
        

    require_once("../conexion_db.php");

    $usuario=$_SESSION["user"];

    $sentencia = 'SELECT * FROM usuarios WHERE NomUsuario="'.$usuario.'"' ;

    if(!($usuario = $GLOBALS["mysqli"]->query($sentencia))) { 
        echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
        echo '</p>'; 
        exit; 
    }

    if(mysqli_num_rows($usuario) < 1)
    {
        echo "<p>Error</p>";
    }
    else
    {
        $fila = $usuario->fetch_object();
        $idUser= $fila->IdUsuario;

        $sentencia = 'INSERT INTO albumes (Titulo, Descripcion, Usuario) VALUES ("'.$_POST[nameAlbum].'", "'.$_POST[descripcion].'", "'.$idUser.'")' ;

        if(!($borrado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        $extra = "crear_foto.php?album=$_POST[nameAlbum]";
        $host = $_SERVER['HTTP_HOST'];
        $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        header("Location: http://$host$uri/$extra");
    }

    require_once("./extra/footer.php");

    ?>
