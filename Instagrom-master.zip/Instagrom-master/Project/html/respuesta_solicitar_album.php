<?php
session_start();

/**************************

Archivo: respuesta_solicitar_album.php

Creado por: Jenifer Boente y Sergio Sebastián

Página de confirmación de solicitud de álbum.

*****************************/

    $Titulo="Solicitar Album - Instagrom";
         require_once("./extra/head.php");
    ?>
   
   
    <?php
     require_once("./extra/header_control.php");
    ?>
    

    <main>
        <h1>Pedido confirmado:</h1>
        <p>Se ha confirmado su pedido con los siguientes datos:</p>
        
        <ul>
            <li>Nombre y apellidos :  <?php echo $_POST["nombre"]; ?> <?php echo $_POST["apellidos"]; ?></li>
            <li>Correo electrónico:  <?php echo $_POST["email"]; ?> </li>
            <li>Dirección de envío:<?php echo $_POST["calle"]; ?>,<?php echo $_POST["numero"]; ?>, <?php echo $_POST["piso"]; ?>, <?php echo $_POST["cod_postal"]; ?>, <?php echo $_POST["localidad"]; ?>, <?php echo $_POST["provincia"]; ?>, <?php echo $_POST["Pais"]; ?></li>
            <li>Fecha de entrega estimada: <?php echo $_POST["fecha"]; ?></li>
            <li>Telefono :  <?php echo $_POST["telefono"]; ?><br><br></li>
              <?php   
                $n_paginas=6;
                $n_hojas=28;
                $precio_final=0;

                if ($n_paginas > 11) $precio_final = 4*0.1 + 7*0.08 + ($n_paginas-11)*0.07;
                else if ($n_paginas > 4) $precio_final = 4*0.1 + ($n_paginas-4)*0.08;
                else $precio_final = $n_paginas*0.1;

                if($_POST["resolucion"] > 300) $precio_final += $n_paginas*3*0.02;
                if($_POST["impresion"] == "color") $precio_final += $n_paginas*3*0.05;

                $precio_final *= $_POST["copias"];
            ?>

            <li>Coste total: <?php echo $precio_final; ?> €</li>
        </ul>

        <form action="perfil.php">
            <button type="submit" class="button">Aceptar</button>
        </form>
    </main>

  <?php
    require_once("../conexion_db.php");

    $sentencia = 'INSERT INTO solicitudes (Album, Nombre, Titulo, Descripcion, Email, d_Calle, d_CP, d_Numero, d_Pais, d_Localidad, d_Provincia, Color, Copias, Resolucion, IColor, FRegistro, Coste) VALUES ("'.$_POST["album_selec"].'", "'.$_POST["nombre"].'", "'.$_POST["alb_titulo"].'", "'.$_POST["txt_adicional"].'", "'.$_POST["email"].'", "'.$_POST["calle"].'", "'.$_POST["cod_postal"].'", "'.$_POST["piso"].'", "'.$_POST["Pais"].'", "'.$_POST["localidad"].'", "'.$_POST["provincia"].'", "'.$_POST["color_portada"].'", "'.$_POST["copias"].'", "'.$_POST["resolucion"].'", "'.$_POST["impresion"].'", "'.$_POST["fecha"].'", "'.$precio_final.'")' ;

    if(!($insert = $GLOBALS["mysqli"]->query($sentencia))) { 
        echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
        echo '</p>'; 
        exit; 
    }

 require_once("./extra/footer.php");
 ?>   
 