<?php
session_start();


/**************************

Archivo: crear_foto.php

Creado por: Jenifer Boente y Sergio Sebastián

Página que permite al usuario subir una foto.

*****************************/

$extra = 'perfil_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si NO estas registrado redireccionar a inaccesible
if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
    header("Location: http://$host$uri/$extra");
}
    $Titulo="Crear Album - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>

        
    
    <main>
        <form method="POST" action="guardar_foto.php"  enctype= "multipart/form-data">
                <h1>Crea una foto</h1>
            <p><label> Titulo : <input id="titulo"  type="text" name="titulo" required></label></p>
                <p>  <label for="descripcion">Descripción: </label>
                    <textarea rows="4" cols="50" id="descripcion" name="descripcion" placeholder="Descripción"></textarea>
                </p>

            <p><label> Fecha <input id="fecha" type="date" name="fecha"></label></p><!--  onchange=" validarFecha (this.value)"  -->
            <p><label> País: <select id="pais" name="pais">
                <?php
                require_once("../conexion_db.php");
                require_once("./extra/listadoPaises.php");
                ?>

            </select></label></p>

            <p><label>  Foto:  <input id="foto-nueva" name="foto-nueva" type="file"></label></p>

            <p><label> Texto alternativo : <input id="alternativo"  type="text" name="alternativo"></label></p>

            <p><label>Album :
                <select id="album" name="album" required>

                    <?php
                    
                        require_once("./extra/selectAlbum.php");
                    ?>
                </select></label></p>

            <input type="submit" value="Crear" class="button">
        </form>
          

    </main>
    
    <?php
    require_once("./extra/footer.php");
    ?>    
