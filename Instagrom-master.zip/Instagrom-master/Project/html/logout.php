<?php
session_start();

/**************************

Archivo: logout.php

Creado por: Jenifer Boente y Sergio Sebastián

Controla el cierre de sesión, borrando cookies y destruyendo la sesión.

*****************************/

    $extra = 'index.php';
    $host = $_SERVER['HTTP_HOST'];
    $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    $uri = substr($uri, 0, -5);

    // Borra todas las variables de sesión
    $_SESSION = array();
    if(isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 90 * 24 * 60 * 60, '/');
    }

    // Borra la cookie que almacena la sesión
    if(isset($_COOKIE['user'])) {
        setcookie('user', '', time() - 90 * 24 * 60 * 60, '/');
        setcookie('pass', '', time() - 90 * 24 * 60 * 60, '/');
        setcookie('count', 0, time() - 90 * 24 * 60 * 60, '/');
    }
    setcookie('estilo', '', time() - 90 * 24 * 60 * 60, '/');
    setcookie('last_day', '', time() - 90 * 24 * 60 * 60, '/');
	setcookie('fecha', '', time() - 90 * 24 * 60 * 60, '/');

    // Finalmente, destruye la sesión
    session_destroy();

    header("Location: http://$host$uri/$extra");
?>
