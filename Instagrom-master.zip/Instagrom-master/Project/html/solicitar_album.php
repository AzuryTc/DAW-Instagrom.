<?php
session_start();

/**************************

Archivo: solicitar_album.php

Creado por: Jenifer Boente y Sergio Sebastián

Página desde la que puedes solicitar un álbum.

*****************************/

    $Titulo="Solicitar Album - Instagrom";
         require_once("./extra/head.php");
    ?>

    <?php
     require_once("./extra/header_control.php");
    ?>
    
    <main>
        <h1>FORMULARIO DE SOLICITUD DE ÁLBUM</h1>
        <h4>Solicita aqui tu album con envio a domicilio. Consulta a continuacion las diferentes tarifas y rellena el formulario.</h4>

        <h2>Tarifas.</h2>

        <table>
            <tr>
                <th>Concepto</th>
                <th>Tarifa</th>
            </tr>
            <tr>
                <td>&lt; 5 páginas</td>
                <td>0.10 € por página</td>
            </tr>
            <tr>
                <td>Entre 5 y 10 páginas</td>
                <td>0.08 € por página</td>
            </tr>
            <tr>
                <td>&gt; 10 páginas</td>
                <td>0.07 € por página</td>
            </tr>
            <tr>
                <td>Blanco y negro</td>
                <td>0 €</td>
            </tr>
            <tr>
                <td>Color</td>
                <td>0.05 € por foto</td>
            </tr>
            <tr>
                <td>Resolución &gt; 300 dpi</td>
                <td>0.02 € por foto</td>
            </tr>
        </table>

        <h2>Ejemplo de precios</h2>

        <table id="precio-tarifas">
            <tr>
                <th></th>
                <th></th>
                <th colspan="2">Blanco y negro</th>
                <th colspan="2">Color</th>
            </tr>

            <tr>
                <th>Número de páginas</th>
                <th>Número de fotos</th>
                <th>150-300 dpi</th>
                <th>450-900 dpi</th>
                <th>150-300 dpi</th>
                <th>450-900 dpi</th>
            </tr>
            <?php 
                for($i=1; $i<16; $i++) {
                    echo "<tr>";

                    for($j=0; $j<6; $j++) {
                        $x = 0;
			
                        if ($j === 0) $x = $i;
                        else if($j === 1) $x = $i*3;
                        else {
                            if ($i > 11) $x = 4*0.1 + 7*0.08 + ($i-11)*0.07;
                            else if ($i > 4) $x = 4*0.1 + ($i-4)*0.08;
                            else $x = $i*0.1;
                        }
                        
                        if($j === 3) $x += $i*3*0.02;
                        else if($j === 4) $x += $i*3*0.05;
                        else if($j === 5) $x += $i*3*0.05+$i*3*0.02;

                        echo "<td>$x</td>";
                    }
                    echo "</tr>";
                }
            ?>
        </table>
        
        <br>
        
        <form method="post" action="respuesta_solicitar_album.php"> 

            <p> Rellena el siguiente formulario con tus datos para solicitar el álbum. (Los campos marcados con un (*) son obligatorios)<br /></p>

            <fieldset>
                <legend>Datos del álbum:</legend>

                <label for="alb_titulo"> Título *: </label>
                <input id="alb_titulo" type="text" name="alb_titulo" size="25"  maxlength="200" required>

                <p><label for="txt_adicional">Texto adicional:</label></p>
                <textarea id="txt_adicional" name="txt_adicional" rows="3" cols="30" placeholder="Dedicatoria, descripción del álbum, ..." maxlength="4000" ></textarea>
                
                <p><label for="color_portada">Color de la portada: </label>
                <input id="color_portada" type="color" name="color_portada"/></p>

                <p><label>Impresión *:</label>
                <input type="radio" id="impresion_color" name="impresion" value="color" required>
                <label for="impresion_color">Color</label>
                <input type="radio" id="impresion_byn" name="impresion" value="byn" required>
                <label for="impresion_byn">Blanco y negro</label></p>

                <p><label for="resolucion">Resolución:</label><input type="range" name="resolucion" id="resolucion" min="150" max="900" step="150" value="150" onchange="document.getElementById('outresolucion').textContent=this.value"><output id="outresolucion">150</output> <span>DPI</span></p>
                <p><label for="copias">Número de copias *:</label><input id="copias" type="number" name="copias" min="1" value="1" required/></p>
                <p><label>Album solicitado *:
                <select id="album_selec" name="album_selec" required>

                    <?php
                        require_once("../conexion_db.php");
                        require_once("./extra/selectAlbum.php");
                    ?>
                </select></label></p>
            </fieldset>

            <fieldset>
                <legend>Datos de envío:</legend>
                <p><label> Nombre *: <input type="text" name="nombre" maxlength="200" required/> </label></p>
                <p><label> Apellidos *: <input type="text" name="apellidos" maxlength="200" required/></label></p>
                <p><label> Correo electrónico *: <input type="email" name="email" maxlength="200" required /></label></p>
                <p><label> Dirección *:
                        <input type="text" name="calle" placeholder="Calle" maxlength="200" required />
                        <input type="number" name="numero" placeholder="Número" min="0" required />
                        <input type="text" name="piso" placeholder="piso" maxlength="200" required />
                        <input type="text" name="cod_postal" placeholder="Código postal" maxlength="200" required />
                        <select name="localidad" required>
                            <option value="" disabled selected>Localidad</option>
                            <option value="Alicante">Alicante</option>
                        </select>
                        <select name="provincia" required>
                            <option value="" disabled selected>Provincia</option>
                            <option value="Alicante">Alicante</option>
                        </select>
                        <select name="Pais" required>
                                                        

                             <?php
                       
                        require_once("./extra/listadoPaises.php");
                    ?>
                        </select>
                </label></p>
                <p><label> Teléfono: <input type="tel" name="telefono" /></label></p>
                <p><label> Fecha de recepción: <input id="fecha" type="date" name="fecha" />(Fecha aproximada de recepción)</label></p>

                <p><input type="submit" value="Solicitar" class="button"></p>
            </fieldset>
        </form>
    </main>

      <?php
     require_once("./extra/footer.php");
     ?> 