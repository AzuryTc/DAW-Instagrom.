<?php
session_start();
require_once("../conexion_db.php");

/**************************

Archivo: controlRegistro.php

Creado por: Jenifer Boente y Sergio sebastian 

Archivo gestiona y valida los registros de usuario.

*****************************/

$hayPost = false;
foreach ($_POST as $value){
	if(isset($value)){
		$hayPost=true;
	}
}
if($hayPost==true){	
	$sanearPost = $_POST;
	foreach($sanearPost as $key => $value){
		$GLOBALS["mysqli"]->real_escape_string($value);
	}
	if($sanearPost["contraseña"] != $sanearPost["contraseña-repetir"]){
		$mysqli->close();
		$host = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra = 'registro.php?FAILCONTRASEÑA';
		header("Location: http://$host$uri/$extra");

		exit;
	}
	if(!empty($sanearPost["fecha"])){
		$fechaActual = date('Y-m-d');
		if($fechaActual <= $sanearPost["fecha"]){

			$mysqli->close();
			$host = $_SERVER['HTTP_HOST'];
			$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
			$extra = 'registro.php?FAILFECHA';
			header("Location: http://$host$uri/$extra");

			exit;
		}
	}
		
	

	//insertar datos base de datos
	require_once("./extra/validacion-registro.php");
	
	

		if($datosCorrectos){

			//primero comprobamos si existe ya el nombre de usuario
			$sentencia = 'SELECT * FROM usuarios WHERE NomUsuario =' . "'" . $sanearPost["nombre"] . "'";

			
			if(!($resultado = $mysqli->query($sentencia))) { 
				echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
				echo '</p>'; 
				exit; 
			}
			if(mysqli_num_rows($resultado)){ 
				$resultado->free();
				$host = $_SERVER['HTTP_HOST'];
				$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				$extra = 'registro.php?FAILNOMBREUSUARIOEXISTENTE';
				header("Location: http://$host$uri/$extra");
				exit;
			}
			else{
				
				$resultado->free();
				require_once("rellenarInsertarDatosRegistro.php");

				

			if(!empty($_FILES["imagen"]) && is_uploaded_file($_FILES["imagen"]["tmp_name"])){
				if($_FILES["imagen"]["error"] > 0) {

						$host = $_SERVER['HTTP_HOST'];
						$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
						$extra = 'registro.php?FAILIMAGEN';
						header("Location: http://$host$uri/$extra");
						exit;

				}	else{ 

					



                       	$arrayNomArchivo = explode(".", $_FILES['imagen']['name']);
                      

						$extensionArchivo = $arrayNomArchivo[sizeof($arrayNomArchivo) - 1];

						
						$nomFile = $_POST["nombre"] . "." . $extensionArchivo;

                        $directorio="../images/fotosPerfil/" . $nomFile; 

       
                       
               		 move_uploaded_file($_FILES["imagen"]["tmp_name"],  $directorio);
                        
                        
                        $foto="/fotosPerfil/".$nomFile;
						$insertarDatos = $insertarDatos . ',' . "'" . $foto . "'" ;
                    }
				} else{
						$insertarDatos = $insertarDatos . ",''";
					}
		
				
				
				$insertarDatos = $insertarDatos . ",SYSDATE(),1";

				$sentencia = 'INSERT INTO usuarios (IdUsuario, NomUsuario, Clave, Email, Sexo, FNacimiento, Ciudad, Pais, Foto, FRegistro, Estilo) VALUES (' . $insertarDatos . ')';

				
				if(!($resultado = $mysqli->query($sentencia))) { 
					
					$host = $_SERVER['HTTP_HOST'];
					$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
					$extra = 'registro.php?FAILSENTENCIA';
					
					header("Location: http://$host$uri/$extra");

				}



				if($mysqli->affected_rows >= 1){

					$idUsuarioFichero = $mysqli->insert_id;
					$dir = "../images/fotosPerfil/";
					$newName = $idUsuarioFichero . "." . $extensionArchivo;
					
					if (is_dir($dir)) {
						$fotoAnt="../images".$foto;
					   $fotoAct = $dir . $newName;
					   rename($fotoAnt, $fotoAct);   
					}

					$fotoAct = "'/fotosPerfil/" . $newName . "'";
					$sentencia = 'UPDATE usuarios SET Foto = ' . $fotoAct . ' WHERE IdUsuario = ' . $idUsuarioFichero;
					
					if(!($resultado = $mysqli->query($sentencia))) { 
						echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
						echo '</p>'; 
						exit; 
					}

					$nombreusu=$_POST["nombre"];

					$host = $_SERVER['HTTP_HOST'];
					$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
					$extra = "extra/resultado-registro-bien.php?usu='".$nombreusu."'";
					
					header("Location: http://$host$uri/$extra");
				}else{

					$host = $_SERVER['HTTP_HOST'];
					$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
					$extra = 'registro.php?FAILREDIREC';
					header("Location: http://$host$uri/$extra");
				}
			 }
		}
		else{
			//$mysqli->close();
			$host = $_SERVER['HTTP_HOST'];
			$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
			$extra = 'registro.php?FAILERROR2:'.$NumError;
			header("Location: http://$host$uri/$extra");
		}
}
else{
		//$mysqli->close();
		$host = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra = 'registro.php?FAILERROR3';
		header("Location: http://$host$uri/$extra");
}

?>


