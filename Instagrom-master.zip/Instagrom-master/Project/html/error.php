<?php
session_start();

/**************************

Archivo: error.php

Creado por: Jenifer Boente y Sergio Sebastián

Página a la que se redirige al usuario cuando intenta acceder a páginas a las cuales no tiene permiso.

*****************************/
        $Titulo="Error - Instagrom";
        require_once("./extra/head.php");
    ?>
     <?php
     require_once("./extra/header-sesion-off.php");
    ?>
        
    <main>
        <h1>ERROR</h1>
        <p>Para acceder a esta página debe estar registrado.</p>
        <a href="registro.php" class="button">REGÍSTRATE</a>
    </main>

     <?php
     require_once("./extra/footer.php");
     ?>
