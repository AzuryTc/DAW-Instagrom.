<?php
session_start();

/**************************

Archivo: perfil_publico.php

Creado por: Jenifer Boente y Sergio Sebastián

Página de perfil.

*****************************/

    $extra = 'registro_inaccesible.php';
    $host = $_SERVER['HTTP_HOST'];
    $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si estas registrado redireccionar a inaccesible
    if((isset($_SESSION["user"]) && isset($_SESSION["pass"]))  || (isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) )){
        header("Location: http://$host$uri/$extra");
    }
    $Titulo="Registro - Perfil";
    require_once("./extra/head.php");
    ?>


    <?php
    require_once("./extra/header-sesion-off.php");
    ?>
    

    <main>


        <?php
        require_once("../conexion_db.php");

        $usuarioIdPerfil=$_GET["perfil"];


        $sentencia = 'SELECT * FROM  usuarios WHERE IdUsuario='.$usuarioIdPerfil;


        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            $fila = $resultado->fetch_object();

            $Nombre=$fila->NomUsuario;
            $fotousu=$fila->Foto;
            $fechaRegistro=$fila->FRegistro;



            echo<<<articulo
            <h1>Usuario : $Nombre</h1>
            

            <img src="../images/$fotousu" alt="foto de perfil del usuario" class="userPerfilImg">
            <p>Es usuario desde:  $fechaRegistro </p>

articulo;
            
        }
        ?>



        <h3>Albums del usuario:</h3>
        <ul>



           <?php

           $sentencia= 'SELECT * FROM albumes a JOIN usuarios ON (a.Usuario=usuarios.IdUsuario) WHERE a.Usuario = ' .$usuarioIdPerfil;

           if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            while($fila = $resultado->fetch_assoc()){
                $tit=$fila["Titulo"];
                $idalbum=$fila["IdAlbum"];

         echo<<<articulo

         <li>Album: <a href="ver_album_publico.php?album=$idalbum">$tit</a> .</li>
        
articulo;
            }

        }

     ?>







     <ul>


     </main>

     <?php
     require_once("./extra/footer.php");
     ?>   



