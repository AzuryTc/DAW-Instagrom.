<?php
session_start();

/**************************

Archivo: perfil_inaccesible.php

Creado por: Jenifer Boente y Sergio Sebastián

Página a la que se redirige al usuario cuando intenta acceder al perfil sin estar logeado.

*****************************/

$extra = 'index.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si estas logueado redireccionar a index
if((isset($_SESSION["user"]) && isset($_SESSION["pass"]))  || (isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) )){
	header("Location: http://$host$uri/$extra");
}
    $Titulo="Perfil - Instagrom";
     require_once("./extra/head.php");
?>
<body>        
<?php
    require_once("./extra/header-sesion-off.php");

?>


	<main>
		<p style="color:red; text-align: center; font-size:20px;">No puedes acceder a esta página, logueate <a href="../index.php">aquí</a> para tener acceso.</p>
	</main>


<?php
    require_once("./extra/footer.php");
?>
