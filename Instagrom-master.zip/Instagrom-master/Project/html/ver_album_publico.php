<?php
session_start();

/**************************

Archivo: ver_album_publico.php

Creado por: Jenifer Boente y Sergio Sebastián

Página en la que puedes ver un álbum sin estar logeado.

*****************************/

    $extra = 'registro_inaccesible.php';
    $host = $_SERVER['HTTP_HOST'];
    $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si estas registrado redireccionar a inaccesible
    if((isset($_SESSION["user"]) && isset($_SESSION["pass"]))  || (isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) )){
        header("Location: http://$host$uri/$extra");
    }
    $Titulo="Registro - Albums";
    require_once("./extra/head.php");
    ?>


    <?php
    require_once("./extra/header-sesion-off.php");
    ?>
    

    <main>

  <?php

    
     
        require_once("../conexion_db.php");

        $idalbumm=$_GET["album"];


        $sentencia = 'SELECT * FROM  albumes WHERE IdAlbum='.$idalbumm;


        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            $fila = $resultado->fetch_object();

            $Nombre=$fila->Titulo;
            $desc=$fila->Descripcion;
            



            echo<<<articulo
            <h1>$Nombre</h1>
            <p>$desc</p>
            
articulo;
            
        }
        ?>




    <?php
             $sentencia3 = 'SELECT  min(f.FRegistro) as minimo ,max(f.FRegistro) as maximo , p.NomPais FROM fotos f JOIN albumes a ON a.IdAlbum=f.Album   JOIN paises p ON (p.IdPais = f.Pais) WHERE a.IdAlbum='.$idalbumm . ' ORDER BY (f.FRegistro) DESC ' ;


               if(!($resultado = $GLOBALS["mysqli"]->query($sentencia3))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                echo '</p>'; 
                exit; 
            }

            if(mysqli_num_rows($resultado) >= 1){

               


               
                $filla = $resultado->fetch_assoc();
                $min = $filla["minimo"];
                $max = $filla["maximo"];


                echo "<p>$min hasta $max</p>";

              
            }

        
             $sentencia3 = 'SELECT   p.NomPais FROM fotos f JOIN albumes a ON a.IdAlbum=f.Album   JOIN paises p ON (p.IdPais = f.Pais) WHERE a.IdAlbum='.$idalbumm . ' ORDER BY (f.FRegistro) DESC ' ;


               if(!($resultado = $GLOBALS["mysqli"]->query($sentencia3))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                echo '</p>'; 
                exit; 
            }

            if(mysqli_num_rows($resultado) >= 1){

               


              

                echo "<p>Paises:  ";

                 while($fila = $resultado->fetch_assoc()){

                    $pais = $fila["NomPais"];

                    echo "$pais , ";



                }

                echo "</p>";
            }

         ?>


         <ul id="fotos">
    <?php
             $sentencia2 = 'SELECT f.IdFoto ,f.Titulo,f.Fichero,f.Alternativo,f.Fecha,p.NomPais,f.FRegistro, f.Descripcion FROM fotos f JOIN albumes a ON a.IdAlbum=f.Album   JOIN paises p ON (p.IdPais = f.Pais) WHERE a.IdAlbum='.$idalbumm . ' ORDER BY (f.FRegistro) DESC ' ;


               if(!($resultado = $GLOBALS["mysqli"]->query($sentencia2))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                echo '</p>'; 
                exit; 
            }

            if(mysqli_num_rows($resultado) >= 1){



                while($fila = $resultado->fetch_assoc()){
                    $id = $fila["IdFoto"];
                    $tit = $fila["Titulo"];
                    $archivo = $fila["Fichero"];
                    $alt = $fila["Alternativo"];
                    $dia = $fila["Fecha"];
                    $desc = $fila["Descripcion"];
                    $pais = $fila["NomPais"]; 
                

                  
                   

             echo<<<articulo

             
            

              <li>
                  <div class="div-img" >
                     <img class="img" src="../images/$archivo" alt="$alt" title="$tit">
                  </div>
                    <h2>$tit</h2>
                    <ul>
                        <li>$dia</li>
                        <li>$pais</li>
                        
                    </ul>
                </li>
            
articulo;
                }

            }

         ?>


      </main>

     <?php
     require_once("./extra/footer.php");
     ?>   
