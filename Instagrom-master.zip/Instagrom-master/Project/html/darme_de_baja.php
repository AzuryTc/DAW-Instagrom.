<?php
session_start();

/**************************

Archivo: darme_de_baja.php

Creado por: Jenifer Boente y Sergio Sebastián

Página para darse de baja.

*****************************/

$extra = 'perfil_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si NO estas registrado redireccionar a inaccesible
if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
    header("Location: http://$host$uri/$extra");
}
    $Titulo="Darme de baja - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>

	<main>

		<h1>Darme de baja</h1>

        <p>Perderás estos álbumes:</p>

	<ul id="fotos">

	<?php
	 require_once("../conexion_db.php");


		$usuario=$_SESSION["user"];
	
        $sentencia = 'SELECT * FROM albumes a JOIN usuarios u ON (a.Usuario=u.IdUsuario)  WHERE u.NomUsuario="'.$usuario.'"' ;

        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        $numFotosTotal = 0;

        if(mysqli_num_rows($resultado) >= 1){
            while($fila = $resultado->fetch_assoc()){

            	$Nom=$fila["Titulo"];
            	$id=$fila["IdAlbum"];
	
                $sentencia2 = 'SELECT * FROM fotos WHERE Album="'.$id.'"' ;

                if(!($fotos = $GLOBALS["mysqli"]->query($sentencia2))) { 
                    echo "<p>Error al ejecutar la sentencia <b>$sentencia2</b>: " . $GLOBALS["mysqli"]->error; 
                    echo '</p>'; 
                    exit; 
                }

                $numFotos = mysqli_num_rows($fotos);
          
                $numFotosTotal = $numFotosTotal + $numFotos;

                echo<<<articulo
                <li>
                    <h3><a href="ver_album_privado.php?album=$id">$Nom</a></h3>
                    <p>Número de fotos: $numFotos</p>
                </li>
articulo;
            }
        }
        echo<<<articulo
                </ul>
                <br>
                    <p>Número de fotos totales: $numFotosTotal </p>
articulo;

	?>

    <form action="respuesta_baja.php" method="post">
        <label>Para confirmar, introduzca su contraseña:
        <input type="password" id="pass" name="pass" required></label>
        <input type="submit" class="button">
    </form>    

	</main>

<?php
require_once("./extra/footer.php");
?>   
