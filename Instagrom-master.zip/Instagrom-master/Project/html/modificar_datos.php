<?php
session_start();

/**************************

Archivo: modificar_datos.php

Creado por: Jenifer Boente y Sergio Sebastián

Página que permite modificar tus datos de usuario.

*****************************/

$extra = 'perfil_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si NO estas registrado redireccionar a inaccesible
if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
    header("Location: http://$host$uri/$extra");
}
    $Titulo="Modificar datos - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>
    

	<main>

		<h1>Modificar tus datos:</h1>

		<form  method="post" action="control_mod_datos.php" enctype= "multipart/form-data">


			<p>Contraseña actual: <input type="password" name="rep-pass" required> </input></p>
			<br>
			<br>

			<?php

				

				require_once("../conexion_db.php");


				require_once("./extra/modificar.php");
			?>


		</form>
	</main>

 <?php
 require_once("./extra/footer.php");
 ?>   
