<?php
session_start();
require_once("../conexion_db.php");


 
/**************************

Archivo: control_mod_datos.php

Creado por: Jenifer Boente y Sergio sebastian 

Archivo que contiene el control de datos y la validacion de campos para que el usuario pueda registrarse correctamente.

*****************************/
    



$hayPost = false;
foreach ($_POST as $value){
	if(isset($value)){
		$hayPost=true;
	}
}
if($hayPost==true){	

	$sanearPost = $_POST;
	foreach($sanearPost as $key => $value){
		$GLOBALS["mysqli"]->real_escape_string($value);
	}
	if($sanearPost["contraseña"] != $sanearPost["contraseña-repetir"]){
		$mysqli->close();
		$host = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra = 'registro.php?FAILCONTRASEÑA';
		 header("Location: http://$host$uri/$extra");

		exit;
	}
	if(!empty($sanearPost["fecha"])){
		$fechaActual = date('Y-m-d');
		if($fechaActual <= $sanearPost["fecha"]){

			$mysqli->close();
			$host = $_SERVER['HTTP_HOST'];
			$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
			$extra = 'registro.php?FAILFECHA';
			 header("Location: http://$host$uri/$extra");

			exit;
		}
	}
		
	

	//insertar datos base de datos
	require_once("./extra/validacion-registro.php");
	
	


		

		//primero comprobamos si existe ya el nombre de usuario
		$sentencia = 'SELECT * FROM usuarios WHERE NomUsuario =' . "'" . $_SESSION["user"] . "' AND Clave='".$sanearPost["rep-pass"]."'";


			if(!($resultado = $mysqli->query($sentencia))) { 
				echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
				echo '</p>'; 
				exit; 
			}
			if(!mysqli_num_rows($resultado)){ 
				$resultado->free();
				$host = $_SERVER['HTTP_HOST'];
				$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				$extra = 'modificar_datos.php?PASSERROR';
				 header("Location: http://$host$uri/$extra");;
				exit;
			}
			else{

			 $fila = $resultado->fetch_object();

			 $idusu=$fila->IdUsuario;
			 $Nomusuanterior=$fila->NomUsuario;
			 $ClaveAnterior=$fila->Clave;



			require_once("rellenarModificar.php");
			$modificaDatos=substr($modificaDatos,0, strlen($modificaDatos)-3);


			if(!empty($_FILES["imagen"]) && is_uploaded_file($_FILES["imagen"]["tmp_name"])){
				if($_FILES["imagen"]["error"] > 0) {

						$host = $_SERVER['HTTP_HOST'];
						$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
						$extra = 'registro.php?FAILIMAGEN';
						header("Location: http://$host$uri/$extra");
						exit;
					

				}else{ 

				



                   	$arrayNomArchivo = explode(".", $_FILES['imagen']['name']);
                  

					$extensionArchivo = $arrayNomArchivo[sizeof($arrayNomArchivo) - 1];

					
					$nomFile = $idusu . "." . $extensionArchivo;

                    $directorio="../images/fotosPerfil/" . $nomFile; 

   
                   
           		 move_uploaded_file($_FILES["imagen"]["tmp_name"],  $directorio);
                    
                    
                    $foto="/fotosPerfil/".$nomFile;

                    if(!empty($modificaDatos ) && $modificaDatos!="'"){


					$modificaDatos = $modificaDatos . ',' . "Foto='" . $foto . "'" ;


				}else{

					$modificaDatos = "Foto='" . $foto . "'" ;
                }
			} 

				//modifica los datosnomfinalnomfinal
				$sentencia = 'UPDATE usuarios SET '.$modificaDatos.'  WHERE  IdUsuario='.$idusu ;

				//echo $sentencia;
					
				if(!($resultado = $mysqli->query($sentencia))) { 
					$host = $_SERVER['HTTP_HOST'];
					$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
					$extra = 'modificar_datos.php?FAILSENTENCIA';
					
					 header("Location: http://$host$uri/$extra");


				}



				if($mysqli->affected_rows >= 0){

					if(!empty($nomfinal)){

						$_SESSION["user"]=$nomfinal;

					}
					if(!empty($passfinal)){

						$_SESSION["pass"]=$passfinal;

						
					}

					$nombreusu=$_POST["nombre"];

					$host = $_SERVER['HTTP_HOST'];
					$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
					$extra = "perfil.php";


					
					 header("Location: http://$host$uri/$extra");
				}else{

					$host = $_SERVER['HTTP_HOST'];
					$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
					$extra = 'modificar_datos.php?FAILREDIREC';
					 header("Location: http://$host$uri/$extra");
				}
			 }
	}
	}
	else{
		
			$mysqli->close();
			$host = $_SERVER['HTTP_HOST'];
			$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
			$extra = 'modificar_datos.php?FAILERROR3';
			 header("Location: http://$host$uri/$extra");
	}

?>


