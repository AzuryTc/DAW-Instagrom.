    <?php
    session_start();
    require_once("../conexion_db.php");




    $doc = new DOMDocument('1.0', 'utf-8');
    $doc->preserveWhiteSpace = false;
    $doc->formatOutput = true;

    $instagrom = $doc->createElement('Instagrom');

    $doc->appendChild($instagrom);

    $elemento = $doc->createElement('Title', 'Estos son tus datos de perfil');

    $instagrom->appendChild($elemento);

            //Datos de perfil de usuario

    $usuarioNom=$_SESSION["user"];


    $sentencia = 'SELECT * FROM  usuarios JOIN paises ON (usuarios.Pais = paises.IdPais) WHERE NomUsuario="'.$usuarioNom.'"';


    if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
        echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
        echo '</p>'; 
        exit; 
    }

    if(mysqli_num_rows($resultado) >= 1){

        $fila = $resultado->fetch_object();

        $idusu=$fila->IdUsuario;
        $Nombre=$fila->NomUsuario;
        $fotousu=$fila->Foto;
        $fechaRegistro=$fila->FRegistro;
        $ciu=$fila->Ciudad;
        $pais=$fila->NomPais;
        $email=$fila->Email;
        $cumpleanyos=$fila->FNacimiento;

        $genero=$fila->Sexo;

        if($genero==1){

            $sex="chica";

        }else{

            $sex="chico";

        }





        $element=$doc->createElement('Usuario');
        $instagrom->appendChild($element);

        $element1=$doc->createAttribute('id');
        $element1->nodeValue=$idusu;
        $element->appendChild($element1);

        $element2=$doc->createElement('Nombre');
        $element2->nodeValue=$Nombre;
        $element->appendChild($element2);

        $element3=$doc->createElement('Foto');
        $element3->nodeValue=$fotousu;
        $element->appendChild($element3);

        $element4=$doc->createElement('Registrado');
        $element4->nodeValue=$fechaRegistro;
        $element->appendChild($element4);

        $element5=$doc->createElement('Pais');
        $element5->nodeValue=$pais;
        $element->appendChild($element5);

        $element6=$doc->createElement('Ciudad');
        $element6->nodeValue=$ciu;
        $element->appendChild($element6);

        $element7=$doc->createElement('CorreoElectronico');
        $element7->nodeValue=$email;
        $element->appendChild($element7);

        $element8=$doc->createElement('FechaNacimiento');
        $element8->nodeValue=$cumpleanyos;
        $element->appendChild($element8);

        $element8=$doc->createElement('Genero');
        $element8->nodeValue=$sex;
        $element->appendChild($element8);



    }

    $elementAlbumTit=$doc->createElement('Albumes');
    $instagrom->appendChild($elementAlbumTit);

    //Sus Albumes y fotos del album.

    $sentencia = 'SELECT * FROM albumes a JOIN usuarios u ON (a.Usuario=u.IdUsuario)  WHERE u.IdUsuario="'.$idusu.'"' ;

    if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
        echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
        echo '</p>'; 
        exit; 
    }

    if(mysqli_num_rows($resultado) >= 1){
        while($fila = $resultado->fetch_assoc()){

            $NomAlbum=$fila["Titulo"];
            $descAlbum=$fila["Descripcion"];
            $idAlbum=$fila["IdAlbum"];

              //Elementos del Album

            
            
            $elementAlbum=$doc->createElement('Album');
            $elementAlbumTit->appendChild($elementAlbum);

            $element1a=$doc->createAttribute('id');
            $element1a->nodeValue=$idAlbum;
            $elementAlbum->appendChild($element1a);


            $element2a=$doc->createElement('Titulo');
            $element2a->nodeValue=$NomAlbum;
            $elementAlbum->appendChild($element2a);

            $element3a=$doc->createElement('Descripcion');
            $element3a->nodeValue=$descAlbum;
            $elementAlbum->appendChild($element3a);



            $elementFotoTit=$doc->createElement('Fotos');
            $elementAlbum->appendChild($elementFotoTit);





            $sentencia2 = 'SELECT f.IdFoto ,f.Titulo,f.Fichero,f.Alternativo,f.Fecha,p.NomPais,f.FRegistro, f.Descripcion FROM fotos f JOIN albumes a ON a.IdAlbum=f.Album   JOIN paises p ON (p.IdPais = f.Pais) WHERE a.IdAlbum='.$idAlbum . ' ORDER BY (f.FRegistro) DESC ' ;


            if(!($resultado2 = $GLOBALS["mysqli"]->query($sentencia2))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                echo '</p>'; 
                exit; 
            }

            if(mysqli_num_rows($resultado2) >= 1){



                while($fila2 = $resultado2->fetch_assoc()){
                    $idf = $fila2["IdFoto"];
                    $titf = $fila2["Titulo"];
                    $descf = $fila2["Descripcion"];
                    $diaf = $fila2["Fecha"];
                    $paisf = $fila2["NomPais"]; 
                    $archivof = $fila2["Fichero"];

                    
                    
                //Elementos de la foto
                    
                    $elementf=$doc->createElement('Foto');
                    $elementFotoTit->appendChild($elementf);

                    $element1f=$doc->createAttribute('id');
                    $element1f->nodeValue=$idf;
                    $elementf->appendChild($element1f);


                    $element2f=$doc->createElement('Titulo');
                    $element2f->nodeValue=$titf;
                    $elementf->appendChild($element2f);

                    $element3f=$doc->createElement('Descripcion');
                    $element3f->nodeValue=$descf;
                    $elementf->appendChild($element3f);

                    $element4f=$doc->createElement('Fecha');
                    $element4f->nodeValue=$diaf;
                    $elementf->appendChild($element4f);

                    $element5f=$doc->createElement('Pais');
                    $element5f->nodeValue=$paisf;
                    $elementf->appendChild($element5f);

                    $element6f=$doc->createElement('Archivo');
                    $element6f->nodeValue=$archivof;
                    $elementf->appendChild($element6f);
                    

                }

            }

        }
    }


       //Para que se descargue correctamente     

    $nombreArchivo="Datos-Usuario-".$idusu.".xml";

    $doc->save( $nombreArchivo);

    header("Content-Type: text/xml");
    header('Content-Disposition: attachment; filename='. $nombreArchivo);

    header("Content-Transfer-Encoding: binary"); 
    header('Pragma: no-cache'); 
    header('Expires: 0');
        // Send the file contents.
    set_time_limit(0);
    ob_clean();
    flush();
    readfile( $nombreArchivo);
    unlink( $nombreArchivo);
    ?>
