<?php

/**************************

Archivo: registro.php

Creado por: Jenifer Boente y Sergio Sebastián

Página de registro.

*****************************/

$Titulo="Registro - Instagrom";
require_once("./extra/ctr_acces_no_restrictivo.php");


?>
    

	<main>

		<h1>FORMULARIO DE REGISTRO</h1>

		<form  method="post" action="controlRegistro.php" enctype= "multipart/form-data">

			<?php 
				require_once("./extra/modificar.php");
			?>


		</form>
	</main>

 <?php
 require_once("./extra/footer.php");
 ?>   
