<?php
session_start();

/**************************

Archivo: repuesta_baja.php

Creado por: Jenifer Boente y Sergio Sebastián

Página que muestra el resultado de darse de baja.

*****************************/
    $Titulo="Darme de baja - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>

	<main>

		<h1>Darme de baja</h1>

	<?php
	 require_once("../conexion_db.php");


        $usuario=$_SESSION["user"];
        $pass = $_POST['pass'];
	
        $sentencia = 'SELECT * FROM usuarios WHERE NomUsuario="'.$usuario.'" AND Clave="'.$pass.'"' ;

        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) < 1)
        {
            echo "<p>Error al darse de baja. ¿Pusiste mal la contraseña?</p>";
        }
        else
        {
            $sentencia = 'DELETE FROM usuarios WHERE NomUsuario="'.$usuario.'" AND Clave="'.$pass.'"' ;

            if(!($borrado = $GLOBALS["mysqli"]->query($sentencia))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
                echo '</p>'; 
                exit; 
            }

            $extra = 'logout.php';
            $host = $_SERVER['HTTP_HOST'];
            $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
            header("Location: http://$host$uri/$extra");
        }

	?>
    

	</main>

<?php
require_once("./extra/footer.php");
?>   
