<?php
session_start();

/**************************

Archivo: mis_albumes.php

Creado por: Jenifer Boente y Sergio Sebastián

Página que muestra los álbumes del usuario.

*****************************/

$extra = 'perfil_inaccesible.php';
$host = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
//si NO estas registrado redireccionar a inaccesible
if((!isset($_SESSION["user"]) || !isset($_SESSION["pass"])) && (!isset($_COOKIE["user"]) || !isset($_COOKIE["pass"]))){
    header("Location: http://$host$uri/$extra");
}
    $Titulo="Mis albumes - Instagrom";
         require_once("./extra/head.php");
    ?>
   
    
    <?php
     require_once("./extra/header_control.php");
    ?>

	<main>

		<h1>Mis Albumes:</h1>

	<ul id="fotos">

	<?php
	 require_once("../conexion_db.php");


		$usuario=$_SESSION["user"];
	
        $sentencia = 'SELECT * FROM albumes a JOIN usuarios u ON (a.Usuario=u.IdUsuario)  WHERE u.NomUsuario="'.$usuario.'"' ;

        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            while($fila = $resultado->fetch_assoc()){

            	$Nom=$fila["Titulo"];
            	$desc=$fila["Descripcion"];
            	$id=$fila["IdAlbum"];

          
                

                echo<<<articulo
                <li>
                    <h3><a href="ver_album_privado.php?album=$id">$Nom</a></h3>
                    <p>$desc</p>

                </li>
articulo;
            }
        }






	?>

	</ul>
    <br>
<a href="mis_fotos.php" class="button"> Ver todas mis fotos</a>

	</main>

<?php
require_once("./extra/footer.php");
?>   
