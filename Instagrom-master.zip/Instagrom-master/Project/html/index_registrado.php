<?php
session_start();

/**************************

Archivo: index_registrado.php

Creado por: Jenifer Boente y Sergio Sebastián

Página principal para el usuario registrado.

*****************************/

        $Titulo="Inicio - Instagrom";
         require_once("./extra/head.php");
    ?>
        
    <?php
    require_once("./extra/header_control.php");
    require_once("create_xml_cinco_fotos.php");
    ?>

    <?php if(isset($_COOKIE["user"]) && isset($_COOKIE["pass"]) && isset($_COOKIE['count'])): ?>
            <div style="background: #E6E6E6; padding: 5px; border: solid 1px black; border-radius: 10px; text-align: center;">
                <p style="color: black;font-size: 20px;padding: 5px; margin: 5px;">La última vez que iniciaste sesión fue: <?php

                    if(isset($_COOKIE["last_day"])){

                        echo ($_COOKIE["last_day"]);

                    }else if (isset($_COOKIE["fecha"])){
                        echo ($_COOKIE["fecha"]);
                    }
                    else{


                        echo "No hay ultima conexion por que eres un nuevo usuario.";
                    }



                    
                ?> </p>
            </div>
        <?php endif;?>

    <main>
        <div>
            <h1>Últimas fotos</h1>
            <form action="busqueda.php" method="GET"  id="form-buscar">
                <label>Búsqueda: &nbsp<input type="text" id="busqueda" name="busqueda"></label>
                <input type="submit" value="Buscar" class="button">
            </form>
        </div>
        <ul id="fotos">
          <?php 

        require_once("../conexion_db.php");

        $sentencia = 'SELECT * FROM fotos';
        if(!($resultado = $mysqli->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
            echo '</p>'; 
            exit; 
        }


        if(mysqli_num_rows($resultado) >= 1){
            mostrarUltimasImagenes();
        }

        $resultado->free();




    function mostrarUltimasImagenes(){



        //extraigo las fotos indicando por cual pagina debo empezar y cuantas imagenes mostrar como tope
        $sentencia = 'SELECT * FROM fotos JOIN paises ON (IdPais = Pais)' . ' ORDER BY (FRegistro) DESC ' . 'LIMIT 5 ' ;

        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
            echo '</p>'; 
            exit; 
        }

        if(mysqli_num_rows($resultado) >= 1){
            while($fila = $resultado->fetch_assoc()){

                $id = $fila["IdFoto"];
                $tit = $fila["Titulo"];
                $archivo = $fila["Fichero"];
                $alt = $fila["Alternativo"];
                $dia = $fila["Fecha"];
                $pais = $fila["NomPais"];

                echo<<<articulo
                <li>
                    <div class="div-img" >
                    <a href="foto.php?id=$id"> <img class="img" src="../images/$archivo" alt="$alt" title="$tit" ></a>
                    </div>
                    <h2><a href="foto.php?id=$id">$tit</a></h2>
                    <ul>
                        <li>$dia</li>
                        <li>$pais</li>
                    </ul>
                </li>
articulo;
            }
        }

} 
         ?>
        </ul>
        
        <?php
            $filas = file("../seleccionadas.txt");
            $num = count($filas);
            $seleccionada = mt_rand(1, $num-1);
            $partes = explode('"',$filas[$seleccionada]);
            
            $idFoto = $partes[0];
            $seleccionador = $partes[1];
            $comentario = $partes[2];
            $sentencia = "SELECT fo.Fichero fi, fo.Alternativo al, fo.Titulo ti, fo.Descripcion de, fo.FRegistro fr, fo.Fecha fe, pa.NomPais np, al.IdAlbum id, al.Titulo ta, us.NomUsuario na FROM fotos fo INNER JOIN albumes al ON al.IdAlbum = fo.Album INNER JOIN paises pa ON fo.Pais = pa.IdPais INNER JOIN usuarios us ON al.Usuario = us.IdUsuario WHERE fo.IdFoto = {$idFoto}";
            

            if(!($resultado = $mysqli->query($sentencia))) { 
                echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error;    echo '</p>';   exit; 
                }
            $fila = $resultado->fetch_assoc();
        
            echo "
                <section style='margin-top:10px; border:2px solid black; padding:5px;'>
                    <h2>Foto seleccionada</h2>
                    <article>
                        <p>Seleccionada por: <output>{$seleccionador}</output></p>
                        <p>Comentario: <output>{$comentario}</output></p>
                        <figure>
                            <a href='foto.php?id={$idFoto}'><img src='../images/{$fila['fi']}' alt='{$fila['al']}'></a>    
                            <figcaption>
                                <h2><output>{$fila['ti']}</output></h2>
                                <p>Descripcion: <output>{$fila["de"]}</output></p>
                                <p>Fecha de subida: <output><time datetime='{$fila['fr']}'>".date('d/m/Y H : i', strtotime($fila['fr']))."</time></output></p>
                                <p>Fecha: <output><time datetime='{$fila['fe']}'>".date('d/m/Y', strtotime($fila['fe']))."</time></output></p>
                                <p>País: <output>{$fila["np"]}</output></p>
                                <p>Álbum: {$fila["ta"]}</p>
                                <p>Autor: {$fila['na']}</p>
                            </figcaption>
                        </figure>
                    </article>
                </section>"; 

            
            $str = file_get_contents('consejos.json');
            $json = json_decode($str, true);
            $num = count($json['consejos']);
            $seleccionada = mt_rand(0, $num-1);

            $consejo = $json['consejos'][$seleccionada];

            echo "
                <section style='margin-top:10px; border:2px solid black; padding:5px;'>
                    <h2>Consejo del día</h2>
                    <ul>
                        <li>Categoría: {$consejo['categoria']}</li>
                        <li>Dificultad: {$consejo['dificultad']}</li>
                        <li>Descripción: {$consejo['descripcion']}</li>
                    <ul>
                </section>"; 
        ?>
    </main>

    <?php
     require_once("./extra/footer.php");
    ?>
