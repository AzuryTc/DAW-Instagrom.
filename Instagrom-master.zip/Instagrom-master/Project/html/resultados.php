<?php
session_start();

/**************************

Archivo: resultados.php

Creado por: Jenifer Boente y Sergio Sebastián

Página que muestra los resultados de una búsqueda.

*****************************/

    $Titulo="Resultado de búsqueda - Instagrom";
         require_once("./extra/head.php");
    ?>
   
   
    <?php
     require_once("./extra/header_control.php");
    ?>
        
        <main>

            <article class="busqueda-campos">
                <h2>Criterio de búsqueda:</h2>

                <?php
                    foreach ($_GET as $key => $value) {
                        $clave = $key;

                        if($value != ""){
                            echo"<dt>$clave</dt><dd>$value</dd><br>";
                        }
                    }
                ?>
                
            </article>


            <div>
                <h1>RESULTADO DE BÚSQUEDA:</h1>
                <form action="busqueda.php" method="GET"   id="form-buscar">
                    <label>Búsqueda: &nbsp;<input type="text" id="busqueda" name="busqueda"></label>
                    <input type="submit" value="Buscar" class="button">
                </form>
            </div>

            <ul id="fotos">
               

            <?php 

            //SIN TERMINAR 
                        require_once("../conexion_db.php");

                        $sentencia = 'SELECT * FROM fotos';
                        if(!($resultado = $mysqli->query($sentencia))) { 
                            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $mysqli->error; 
                            echo '</p>'; 
                            exit; 
                        }


                        if(mysqli_num_rows($resultado) >= 1){
                            mostrarUltimasImagenes();
                        }

                        $resultado->free();




                            function mostrarUltimasImagenes(){


                        
                         $busqueda="";


                         //var_dump($_GET);
                            foreach ($_GET as $key => $value) {
                                $clave = $key;
                                
                                if($value != ""){
                                    
                                    if($key=="Titulo:"){

                                        $busqueda.="f.Titulo LIKE '%".$value."%' and ";
                                    }
                                      if($key=="pais"){

                                        $busqueda.='NomPais="'.$value.'"and '; 
                                    }

                                 }
                            }



                            $desde=$_GET["Desde:"];
                            $hasta=$_GET["Hasta:"];




                            if(!empty($desde) && !empty($hasta)){
                                $desde = str_replace("-", "", $desde);
                                $hasta = str_replace("-", "", $hasta);
                                $desde="$desde";
                                $hasta="$hasta";


                                $busqueda.=" f.FRegistro BETWEEN ".$desde." AND ".$hasta."aaaa";

                      // echo  $busqueda;

                            }else{
                                if(!empty($desde) ){
                                    $desde = str_replace("-", "", $desde);

                                    $busqueda.=" f.FRegistro LIKE '%".$desde."%'aaaa";

                                }else if(!empty($hasta)) {
                                $hasta = str_replace("-", "", $hasta);

                                    $busqueda.=" f.FRegistro LIKE '%".$hasta."%'aaaa";

                                }
                            }

                           $busqueda= substr($busqueda, 0, strlen($busqueda)-4);

                           if($busqueda!=""){
                        //extraigo las fotos indicando por cual pagina debo empezar y cuantas imagenes mostrar como tope
                       $sentencia = 'SELECT f.IdFoto ,f.Titulo,f.Fichero,f.Alternativo,f.Fecha,p.NomPais, f.FRegistro, u.NomUsuario, u.IdUsuario FROM fotos f JOIN albumes a ON a.IdAlbum=f.Album  JOIN usuarios u ON a.Usuario=u.IdUsuario JOIN paises p ON (p.IdPais = f.Pais) WHERE '.$busqueda ;

                       //echo $sentencia;

                        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
                            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>:".$GLOBALS["mysqli"]->error; 
                            echo '</p>'; 
                            exit; 
                        }

                        if(mysqli_num_rows($resultado) >= 1){
                            while($fila = $resultado->fetch_assoc()){

                                $id = $fila["IdFoto"];
                                $tit = $fila["Titulo"];
                                $archivo = $fila["Fichero"];
                                $alt = $fila["Alternativo"];
                                $dia = $fila["Fecha"];
                                $pais = $fila["NomPais"];

                                echo<<<articulo
                                <li>
                                    <div class="div-img" >
                                    <a href="foto.php?id=$id"> <img class="img" src="../images/$archivo" alt="$alt" title="$tit" ></a>
                                    </div>
                                    <h2><a href="foto.php?id=$id">$tit</a></h2>
                                    <ul>
                                        <li>$dia</li>
                                        <li>$pais</li>
                                    </ul>
                                </li>
articulo;
                            }
                        }
                    }else{

                        echo<<<articulo
                                <li>
                                    <p>No has buscado nada</p>
                                </li>
articulo;


                    }

                }
             ?>
            





            </ul>
        </main>

      <?php
         require_once("./extra/footer.php");
         ?>   
    </body>
</html>