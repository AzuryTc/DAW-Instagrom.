<?php
//Sentencia select para conseguir los datos de las 5 imagenes

	$doc = new DOMDocument('2.0', 'utf-8');
	$doc->preserveWhiteSpace = false;
	$doc->formatOutput = true;

	$instagrom = $doc->createElement('Instagrom');

	$doc->appendChild($instagrom);

	$elemento = $doc->createElement('Title', 'Estas son las ultimas 5 fotos');

	$instagrom->appendChild($elemento);


	        //extraigo las fotos indicando por cual pagina debo empezar y cuantas imagenes mostrar como tope
	        $sentencia = 'SELECT * FROM fotos JOIN paises ON (IdPais = Pais)' . ' ORDER BY (FRegistro) DESC ' . 'LIMIT 5 ' ;

	        if(!($resultado = $GLOBALS["mysqli"]->query($sentencia))) { 
	            echo "<p>Error al ejecutar la sentencia <b>$sentencia</b>: " . $GLOBALS["mysqli"]->error; 
	            echo '</p>'; 
	            exit; 
	        }

	        if(mysqli_num_rows($resultado) >= 1){
	            while($fila = $resultado->fetch_assoc()){

	                $id = $fila["IdFoto"];
	                $tit = $fila["Titulo"];
	                $archivo = $fila["Fichero"];
	                $dia = $fila["Fecha"];
	                $pais = $fila["NomPais"];


	                $element=$doc->createElement('Foto');
	                $instagrom->appendChild($element);

	                $element1=$doc->createAttribute('id');
	                $element1->nodeValue=$id;
	                $element->appendChild($element1);

	                $element2=$doc->createElement('titulo');
	                $element2->nodeValue=$tit;
	                $element->appendChild($element2);

	                $element3=$doc->createElement('archivo');
	                $element3->nodeValue=$archivo;
	                $element->appendChild($element3);

	                $element4=$doc->createElement('fecha');
	                $element4->nodeValue=$dia;
	                $element->appendChild($element4);

	                $element5=$doc->createElement('pais');
	                $element5->nodeValue=$pais;
	                $element->appendChild($element5);





	       }
		}
-

		$doc->save('fotos.xml');

?>