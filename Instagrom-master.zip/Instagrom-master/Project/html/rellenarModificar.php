<?php

/**************************

Archivo: rellenarModificar.php

Creado por: Jenifer Boente y Sergio sebastian 

Archivo que concatena los datos para el update de modificar datos.
*****************************/
	
	$modificaDatos = "''";
	$nomfinal="";
	$passfinal="";
	
	foreach ($sanearPost as $key => $value) {
	
			if(!empty($value)){

				if($key=="nombre"){

					if(is_numeric($value)){
						$nomfinal=$value;
						$modificaDatos = "NomUsuario=".$value.",".$modificaDatos ;


					}
					
					else{
						$nomfinal=$value;
						$modificaDatos = "NomUsuario='".$value."',".$modificaDatos ;
					} 

				} else if($key=="contraseña"){

					if(is_numeric($value)){
						$passfinal=$value;

						$modificaDatos = "Clave=".$value.",".$modificaDatos ;
					}
					
					else{
						$passfinal=$value;
						$modificaDatos = "Clave='".$value."',".$modificaDatos ;
					} 

				} else if($key=="correo"){

					if(is_numeric($value)){
						$modificaDatos = "Email=".$value.",".$modificaDatos ;
					}
					
					else{
						$modificaDatos = "Email='".$value."',".$modificaDatos ;
					} 

				}else if($key=="genero"){

					if(is_numeric($value)){
						$modificaDatos = "Sexo=".$value.",".$modificaDatos ;
					}
					
					else{
						$modificaDatos = "Sexo='".$value."',".$modificaDatos ;
					} 

				}else if($key=="fecha"){

					if(is_numeric($value)){
						$modificaDatos = "FNacimiento=".$value.",".$modificaDatos ;
					}
					
					else{
						$modificaDatos = "FNacimiento='".$value."',".$modificaDatos ;
					} 

				}else if($key=="cuidad"){

					if(is_numeric($value)){
						$modificaDatos = "Ciudad=".$value.",".$modificaDatos ;
					}
					
					else{
						$modificaDatos = "Ciudad='".$value."',".$modificaDatos ;
					} 

				}else if($key=="pais"){

					if(is_numeric($value)){
						$modificaDatos = "Pais=".$value.",".$modificaDatos ;
					}
					
					else{
						$modificaDatos = "Pais='".$value."',".$modificaDatos ;
					} 

				}else if($key=="imagen"){

					continue;

				}

			}
			
		
	}

?>

   